package com.cruisemurder.task;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraftforge.fml.loading.FMLPaths;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** Persistent named cuboid regions used by configurable activities. */
public final class TaskRegionManager {
    private static final Map<String, TaskRegion> REGIONS = new LinkedHashMap<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FMLPaths.CONFIGDIR.get().resolve("cruisemurder-regions.json");
    private static final Map<UUID, BlockPos> POS1 = new HashMap<>(), POS2 = new HashMap<>();
    private TaskRegionManager() {}

    public static void load() {
        if (!Files.exists(FILE)) return;
        try {
            Type type = new TypeToken<List<RegionRecord>>(){}.getType();
            List<RegionRecord> records = GSON.fromJson(Files.readString(FILE), type);
            REGIONS.clear();
            if (records == null) return;
            for (RegionRecord r : records) {
                if (r == null || r.id == null || r.dimension == null) continue;
                ResourceLocation loc = ResourceLocation.tryParse(r.dimension);
                if (loc == null) continue;
                ResourceKey<Level> key = ResourceKey.create(Registries.DIMENSION, loc);
                REGIONS.put(r.id, new TaskRegion(r.id, key, new BlockPos(r.x1,r.y1,r.z1), new BlockPos(r.x2,r.y2,r.z2)));
            }
        } catch (Exception e) { System.err.println("[CruiseMurder] Failed loading regions: " + e.getMessage()); }
    }
    private static void save() {
        List<RegionRecord> records = new ArrayList<>();
        for (TaskRegion r : REGIONS.values()) records.add(new RegionRecord(r));
        try { Files.createDirectories(FILE.getParent()); Files.writeString(FILE, GSON.toJson(records)); }
        catch (IOException e) { System.err.println("[CruiseMurder] Failed saving regions: " + e.getMessage()); }
    }
    public static void setPos(ServerPlayer p, int index) { (index == 1 ? POS1 : POS2).put(p.getUUID(), p.blockPosition()); }
    public static String create(ServerPlayer p, String rawId) {
        String id = rawId.toLowerCase(Locale.ROOT);
        BlockPos a=POS1.get(p.getUUID()), b=POS2.get(p.getUUID());
        if (a == null || b == null) return "请先用 pos1 和 pos2 选择区域两端。";
        REGIONS.put(id, new TaskRegion(id, p.serverLevel().dimension(), a, b));
        save(); return "已创建任务区域 " + id + "，范围 " + a.toShortString() + " 至 " + b.toShortString();
    }
    public static boolean remove(String id) { boolean removed=REGIONS.remove(id.toLowerCase(Locale.ROOT)) != null; if (removed) save(); return removed; }
    public static TaskRegion get(String id) { return REGIONS.get(id.toLowerCase(Locale.ROOT)); }
    public static Collection<TaskRegion> all() { return Collections.unmodifiableCollection(REGIONS.values()); }
    public static String list() {
        if (REGIONS.isEmpty()) return "尚未创建区域。";
        StringBuilder out = new StringBuilder("任务区域：");
        for (TaskRegion r : REGIONS.values()) out.append("\n- ").append(r.id).append(" [").append(r.min.toShortString()).append(" ~ ").append(r.max.toShortString()).append("]");
        return out.toString();
    }
    public static final class RegionRecord {
        public String id, dimension; public int x1,y1,z1,x2,y2,z2;
        public RegionRecord() {}
        RegionRecord(TaskRegion r) { id=r.id; dimension=r.dimension.location().toString(); x1=r.min.getX();y1=r.min.getY();z1=r.min.getZ();x2=r.max.getX();y2=r.max.getY();z2=r.max.getZ(); }
    }
}

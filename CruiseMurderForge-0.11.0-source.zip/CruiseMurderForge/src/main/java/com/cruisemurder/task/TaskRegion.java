package com.cruisemurder.task;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerPlayer;

/** Inclusive cuboid in one dimension. Coordinates are configured by an admin in-game. */
public final class TaskRegion {
    public final String id;
    public final ResourceKey<Level> dimension;
    public final BlockPos min, max;

    public TaskRegion(String id, ResourceKey<Level> dimension, BlockPos a, BlockPos b) {
        this.id = id;
        this.dimension = dimension;
        this.min = new BlockPos(Math.min(a.getX(), b.getX()), Math.min(a.getY(), b.getY()), Math.min(a.getZ(), b.getZ()));
        this.max = new BlockPos(Math.max(a.getX(), b.getX()), Math.max(a.getY(), b.getY()), Math.max(a.getZ(), b.getZ()));
    }

    public boolean contains(ServerPlayer player) {
        if (!player.serverLevel().dimension().equals(dimension)) return false;
        BlockPos p = player.blockPosition();
        return p.getX() >= min.getX() && p.getX() <= max.getX()
            && p.getY() >= min.getY() && p.getY() <= max.getY()
            && p.getZ() >= min.getZ() && p.getZ() <= max.getZ();
    }
}

package com.cruisemurder.task;

import com.cruisemurder.game.MatchManager;
import com.cruisemurder.game.PlayerRoundData;
import com.cruisemurder.item.ModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Server-authoritative fixed-plate interaction, meal pickup, and poison effect. */
@Mod.EventBusSubscriber(modid = "cruisemurder")
public final class DiningTaskEvents {
    private static boolean platePoisoned;

    private DiningTaskEvents() {}

    public static void resetRound() { platePoisoned = false; }

    @SubscribeEvent
    public static void onTakeMeal(PlayerInteractEvent.RightClickBlock event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player.level().isClientSide) return;
        if (MatchManager.state() != MatchManager.State.ACTIVE) return;
        PlayerRoundData data = MatchManager.data(player.getUUID());
        if (data == null || !data.alive || player.isSpectator()) return;
        TaskRegion dining = TaskRegionManager.get("dining");
        if (TaskStationManager.isConfigured("dining_plate")) {
            if (!TaskStationManager.matches("dining_plate", player, event.getPos())) return;
        } else if (dining == null || !dining.contains(player)) {
            return;
        }

        ItemStack held = player.getItemInHand(event.getHand());
        if (held.is(ModItems.POISON_KIT.get())) {
            if (!"KILLER".equals(data.role)) {
                player.sendSystemMessage(Component.literal("你不知道该怎么用这个东西。"));
                event.setCanceled(true);
                return;
            }
            if (platePoisoned) {
                player.sendSystemMessage(Component.literal("这份餐盘已经被动过手脚了。"));
                event.setCanceled(true);
                return;
            }
            platePoisoned = true;
            held.shrink(1);
            player.sendSystemMessage(Component.literal("你趁没人注意，在餐盘上动了手脚。"));
            event.setCanceled(true);
            return;
        }

        if (event.getHand() != net.minecraft.world.InteractionHand.MAIN_HAND || !held.isEmpty()) return;
        if (player.getCooldowns().isOnCooldown(Items.COOKED_SALMON)) return;
        ItemStack meal = new ItemStack(Items.COOKED_SALMON, 1);
        meal.getOrCreateTag().putBoolean("cruisemurder_meal", true);
        if (platePoisoned) {
            meal.getOrCreateTag().putBoolean("cruisemurder_poisoned", true);
            platePoisoned = false;
        }
        player.getCooldowns().addCooldown(Items.COOKED_SALMON, 40);
        if (!player.getInventory().add(meal)) player.drop(meal, false);
        player.sendSystemMessage(Component.literal("你从餐盘里拿了一份餐食。"));
        event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onMealEaten(LivingEntityUseItemEvent.Finish event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player.level().isClientSide) return;
        ItemStack stack = event.getItem();
        if (!stack.hasTag() || !stack.getTag().getBoolean("cruisemurder_meal")) return;
        if (MatchManager.state() != MatchManager.State.ACTIVE) return;
        PlayerRoundData data = MatchManager.data(player.getUUID());
        if (data == null || !data.alive) return;
        if (stack.getTag().getBoolean("cruisemurder_poisoned")) {
            player.sendSystemMessage(Component.literal("喉咙突然一阵发紧……这份餐食有毒！"));
            player.hurt(player.damageSources().magic(), 1000.0F);
            if (player.isAlive()) player.kill();
            return;
        }
        boolean completed = TaskActivityManager.completeStationTask(player, "dining_eat");
        if (!completed) player.sendSystemMessage(Component.literal("吃完了。可惜这次没算进任务里。"));
    }
}

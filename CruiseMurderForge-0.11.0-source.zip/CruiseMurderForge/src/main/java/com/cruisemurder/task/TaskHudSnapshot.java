package com.cruisemurder.task;

/** Small immutable task-progress value copied into the client HUD packet. */
public record TaskHudSnapshot(String name, int progress, int duration, int secondsUntilDeadline) {
    public TaskHudSnapshot {
        name = name == null ? "" : name;
        progress = Math.max(0, progress);
        duration = Math.max(0, duration);
        secondsUntilDeadline = Math.max(0, secondsUntilDeadline);
    }
}

package com.cruisemurder.task;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** Named block stations such as the dining plate and engine console. */
public final class TaskStationManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FMLPaths.CONFIGDIR.get().resolve("cruisemurder-stations.json");
    private static final Map<String, Station> STATIONS = new LinkedHashMap<>();

    private TaskStationManager() {}

    public static void load() {
        if (!Files.exists(FILE)) return;
        try {
            Type type = new TypeToken<List<Station>>() {}.getType();
            List<Station> loaded = GSON.fromJson(Files.readString(FILE), type);
            STATIONS.clear();
            if (loaded != null) {
                for (Station station : loaded) {
                    if (station != null && station.id != null && station.dimension != null) {
                        STATIONS.put(station.id.toLowerCase(Locale.ROOT), station);
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("[CruiseMurder] Failed loading stations: " + e.getMessage());
        }
    }

    private static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(STATIONS.values()));
        } catch (IOException e) {
            System.err.println("[CruiseMurder] Failed saving stations: " + e.getMessage());
        }
    }

    public static String setLookingAt(ServerPlayer player, String rawId) {
        String id = rawId.toLowerCase(Locale.ROOT);
        Vec3 start = player.getEyePosition();
        Vec3 end = start.add(player.getViewVector(1.0F).scale(8.0));
        HitResult hit = player.level().clip(new ClipContext(start, end, ClipContext.Block.OUTLINE,
                ClipContext.Fluid.NONE, player));
        if (!(hit instanceof BlockHitResult blockHit) || hit.getType() != HitResult.Type.BLOCK) {
            return "没看见要设置的方块。请对准餐盘或控制台再试一次。";
        }
        BlockPos pos = blockHit.getBlockPos();
        STATIONS.put(id, new Station(id, player.serverLevel().dimension().location().toString(),
                pos.getX(), pos.getY(), pos.getZ()));
        save();
        return "已设置站点 " + id + "：" + pos.toShortString();
    }

    public static boolean matches(String rawId, ServerPlayer player, BlockPos pos) {
        Station station = STATIONS.get(rawId.toLowerCase(Locale.ROOT));
        if (station == null) return false;
        return station.dimension.equals(player.serverLevel().dimension().location().toString())
                && station.x == pos.getX() && station.y == pos.getY() && station.z == pos.getZ();
    }

    public static boolean isConfigured(String rawId) {
        return STATIONS.containsKey(rawId.toLowerCase(Locale.ROOT));
    }

    public static boolean isNear(String rawId, ServerPlayer player, double radius) {
        Station station = STATIONS.get(rawId.toLowerCase(Locale.ROOT));
        if (station == null || !station.dimension.equals(player.serverLevel().dimension().location().toString())) return false;
        double cx = station.x + 0.5, cy = station.y + 0.5, cz = station.z + 0.5;
        return player.distanceToSqr(cx, cy, cz) <= radius * radius;
    }

    /** Returns true only while the player is aiming at the configured screen block. */
    public static boolean isLookingAt(String rawId, ServerPlayer player, double maxDistance) {
        Station station = STATIONS.get(rawId.toLowerCase(Locale.ROOT));
        if (station == null || !station.dimension.equals(player.serverLevel().dimension().location().toString())) return false;
        Vec3 target = new Vec3(station.x + 0.5, station.y + 0.5, station.z + 0.5);
        Vec3 eye = player.getEyePosition();
        Vec3 toward = target.subtract(eye);
        double distanceSqr = toward.lengthSqr();
        if (distanceSqr < 0.01 || distanceSqr > maxDistance * maxDistance) return false;
        Vec3 look = player.getLookAngle().normalize();
        if (look.dot(toward.normalize()) < 0.90) return false;
        Vec3 end = eye.add(look.scale(maxDistance));
        HitResult hit = player.level().clip(new ClipContext(eye, end, ClipContext.Block.OUTLINE,
                ClipContext.Fluid.NONE, player));
        return hit instanceof BlockHitResult blockHit && blockHit.getType() == HitResult.Type.BLOCK
                && blockHit.getBlockPos().getX() == station.x
                && blockHit.getBlockPos().getY() == station.y
                && blockHit.getBlockPos().getZ() == station.z;
    }

    public static String remove(String rawId) {
        if (STATIONS.remove(rawId.toLowerCase(Locale.ROOT)) == null) return "没有这个站点。";
        save();
        return "已删除站点 " + rawId + "。";
    }

    public static String list() {
        if (STATIONS.isEmpty()) return "还没设置任何站点。请看着方块使用 /cruisemurder station set <id>。";
        StringBuilder out = new StringBuilder("已设置站点：");
        for (Station station : STATIONS.values()) {
            out.append("\n- ").append(station.id).append(" @ ").append(station.dimension)
                    .append(" ").append(station.x).append(" ").append(station.y).append(" ").append(station.z);
        }
        return out.toString();
    }

    public static final class Station {
        public String id;
        public String dimension;
        public int x, y, z;
        public Station() {}
        Station(String id, String dimension, int x, int y, int z) {
            this.id = id; this.dimension = dimension; this.x = x; this.y = y; this.z = z;
        }
    }
}

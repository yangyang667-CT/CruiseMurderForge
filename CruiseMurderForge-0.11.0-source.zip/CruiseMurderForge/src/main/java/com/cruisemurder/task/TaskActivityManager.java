package com.cruisemurder.task;

import com.cruisemurder.config.CruiseConfig;
import com.cruisemurder.game.MatchManager;
import com.cruisemurder.game.PlayerRoundData;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

import java.util.*;

/** Server-authoritative task assignment, deadline, progress, and reward handling. */
public final class TaskActivityManager {
    private static final Map<UUID, Map<String, Integer>> PROGRESS = new HashMap<>();
    private static final Map<UUID, Map<String, Long>> COOLDOWNS = new HashMap<>();
    private static final Map<UUID, String> ACTIVE_STATION_TASKS = new HashMap<>();
    private static final Map<UUID, LinkedHashMap<String, Long>> ASSIGNED_TASKS = new HashMap<>();
    private static long tickCount;

    private TaskActivityManager() {}

    public static void resetRound() {
        PROGRESS.clear();
        COOLDOWNS.clear();
        ACTIVE_STATION_TASKS.clear();
        ASSIGNED_TASKS.clear();
        tickCount = 0;
    }

    /** Give each passenger a small personal task list; deadlines start when the cabin phase ends. */
    public static void assignInitialTasks(MinecraftServer server) {
        long now = tickCount / 20L;
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            PlayerRoundData data = MatchManager.data(player.getUUID());
            if (data == null || !data.alive || "KILLER".equals(data.role)) continue;
            refillAssignments(player.getUUID(), now);
        }
    }

    public static void tick(MinecraftServer server) {
        tickCount++;
        if (tickCount % 20 != 0) return;
        long now = tickCount / 20L;
        CruiseConfig.Settings cfg = CruiseConfig.settings;

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            PlayerRoundData data = MatchManager.data(player.getUUID());
            if (data == null || !data.alive || "KILLER".equals(data.role)) continue;

            UUID playerId = player.getUUID();
            refillAssignments(playerId, now);
            LinkedHashMap<String, Long> assigned = ASSIGNED_TASKS.get(playerId);
            if (assigned == null || assigned.isEmpty()) continue;

            for (CruiseConfig.TaskDefinition task : cfg.tasks.tasks) {
                if (task == null || !task.enabled || task.id == null || task.id.isBlank()
                        || !assigned.containsKey(task.id)) continue;
                String type = task.type == null ? "" : task.type;
                TaskRegion region = TaskRegionManager.get(task.region == null ? "" : task.region);
                boolean inRegion = region != null && region.contains(player);
                if (cfg.tasks.requireRegions && !inRegion) {
                    setProgress(playerId, task.id, 0);
                    if (task.id.equals(ACTIVE_STATION_TASKS.get(playerId))) ACTIVE_STATION_TASKS.remove(playerId);
                    continue;
                }

                switch (type) {
                    case "SWIM_IN_REGION" -> {
                        if (inRegion && (player.isSwimming() || player.isVisuallySwimming())) increment(player, task);
                        else setProgress(playerId, task.id, 0);
                    }
                    case "WATCH_IN_REGION" -> {
                        boolean watching = task.station == null || task.station.isBlank()
                                || !TaskStationManager.isConfigured(task.station)
                                || TaskStationManager.isLookingAt(task.station, player, 16.0);
                        if ((!cfg.tasks.requireRegions || inRegion) && watching) increment(player, task);
                        else setProgress(playerId, task.id, 0);
                    }
                    case "STAY_IN_REGION" -> {
                        if (!cfg.tasks.requireRegions || inRegion) increment(player, task);
                        else setProgress(playerId, task.id, 0);
                    }
                    case "INTERACT_AT_STATION" -> {
                        String activeId = ACTIVE_STATION_TASKS.get(playerId);
                        String station = task.station == null ? "" : task.station;
                        boolean activated = task.id.equals(activeId);
                        boolean near = !station.isBlank() && TaskStationManager.isNear(station, player, 3.5);
                        if (activated && near && (!cfg.tasks.requireRegions || inRegion)) {
                            increment(player, task);
                        } else if (activated) {
                            ACTIVE_STATION_TASKS.remove(playerId);
                            setProgress(playerId, task.id, 0);
                            player.sendSystemMessage(Component.literal("维修中断了。再检查一下控制台。"));
                        }
                    }
                    case "EAT_AT_STATION" -> { /* completed when a tagged meal is eaten */ }
                    default -> { /* Unknown task types are ignored safely. */ }
                }
            }

            // Check deadlines after task progress so a task completed on this tick is not marked late.
            assigned = ASSIGNED_TASKS.get(playerId);
            if (assigned == null) continue;
            for (Map.Entry<String, Long> entry : new ArrayList<>(assigned.entrySet())) {
                if (now < entry.getValue()) continue;
                String taskId = entry.getKey();
                if (cfg.pressure.enabled) {
                    data.pressure = Math.min(cfg.pressure.max, data.pressure + Math.max(0, cfg.tasks.missedTaskPressure));
                }
                setProgress(playerId, taskId, 0);
                if (taskId.equals(ACTIVE_STATION_TASKS.get(playerId))) ACTIVE_STATION_TASKS.remove(playerId);
                assigned.put(taskId, now + Math.max(15, cfg.tasks.refreshSeconds));
                player.sendSystemMessage(Component.literal("工作超时了。你越来越难冷静下来。"));
            }
        }
    }

    private static void refillAssignments(UUID playerId, long now) {
        CruiseConfig.Tasks cfg = CruiseConfig.settings.tasks;
        LinkedHashMap<String, Long> assigned = ASSIGNED_TASKS.computeIfAbsent(playerId, id -> new LinkedHashMap<>());
        int targetCount = Math.max(1, Math.min(5, cfg.activeTaskCount));
        int guard = Math.max(1, cfg.tasks.size());
        while (assigned.size() < targetCount && guard-- > 0) {
            List<CruiseConfig.TaskDefinition> candidates = new ArrayList<>();
            Map<String, Long> cooldowns = COOLDOWNS.getOrDefault(playerId, Collections.emptyMap());
            for (CruiseConfig.TaskDefinition task : cfg.tasks) {
                if (task == null || !task.enabled || task.id == null || task.id.isBlank()) continue;
                if (assigned.containsKey(task.id)) continue;
                if (cooldowns.getOrDefault(task.id, 0L) > now) continue;
                candidates.add(task);
            }
            if (candidates.isEmpty()) break;
            Collections.shuffle(candidates);
            CruiseConfig.TaskDefinition selected = candidates.get(0);
            assigned.put(selected.id, now + Math.max(15, cfg.refreshSeconds));
        }
    }

    private static boolean isAssigned(UUID playerId, String taskId) {
        Map<String, Long> assigned = ASSIGNED_TASKS.get(playerId);
        return assigned != null && assigned.containsKey(taskId);
    }

    public static boolean beginStationTask(ServerPlayer player, String taskId) {
        for (CruiseConfig.TaskDefinition task : CruiseConfig.settings.tasks.tasks) {
            if (task == null || !task.enabled || !Objects.equals(task.id, taskId)
                    || !"INTERACT_AT_STATION".equals(task.type)) continue;
            UUID playerId = player.getUUID();
            PlayerRoundData data = MatchManager.data(playerId);
            if (MatchManager.state() != MatchManager.State.ACTIVE || data == null || !data.alive
                    || "KILLER".equals(data.role) || !isAssigned(playerId, task.id)) return false;
            TaskRegion region = TaskRegionManager.get(task.region == null ? "" : task.region);
            if (CruiseConfig.settings.tasks.requireRegions && (region == null || !region.contains(player))) return false;
            String station = task.station == null ? "" : task.station;
            if (station.isBlank() || !TaskStationManager.isNear(station, player, 3.5)) return false;
            ACTIVE_STATION_TASKS.put(playerId, task.id);
            setProgress(playerId, task.id, 0);
            player.sendSystemMessage(Component.literal("你开始检修设备，先别离开。"));
            return true;
        }
        return false;
    }

    public static boolean completeStationTask(ServerPlayer player, String taskId) {
        UUID playerId = player.getUUID();
        if (!isAssigned(playerId, taskId)) return false;
        for (CruiseConfig.TaskDefinition task : CruiseConfig.settings.tasks.tasks) {
            if (task == null || !task.enabled || !Objects.equals(task.id, taskId)
                    || !("EAT_AT_STATION".equals(task.type) || "INTERACT_AT_STATION".equals(task.type))) continue;
            TaskRegion region = TaskRegionManager.get(task.region == null ? "" : task.region);
            if (CruiseConfig.settings.tasks.requireRegions && (region == null || !region.contains(player))) return false;
            return complete(player, task);
        }
        return false;
    }

    private static void increment(ServerPlayer player, CruiseConfig.TaskDefinition task) {
        int next = getProgress(player.getUUID(), task.id) + 1;
        setProgress(player.getUUID(), task.id, next);
        if (next >= Math.max(1, task.durationSeconds)) {
            boolean rewarded = complete(player, task);
            if (!rewarded) setProgress(player.getUUID(), task.id, 0);
            if ("INTERACT_AT_STATION".equals(task.type)) ACTIVE_STATION_TASKS.remove(player.getUUID());
        }
    }

    private static boolean complete(ServerPlayer player, CruiseConfig.TaskDefinition task) {
        UUID playerId = player.getUUID();
        if (!isAssigned(playerId, task.id)) return false;
        long now = tickCount / 20L;
        Map<String, Long> byTask = COOLDOWNS.computeIfAbsent(playerId, k -> new HashMap<>());
        if (now < byTask.getOrDefault(task.id, 0L)) return false;
        PlayerRoundData data = MatchManager.data(playerId);
        if (MatchManager.state() != MatchManager.State.ACTIVE || data == null || !data.alive) return false;
        data.taskCompletions++;
        data.coins += Math.max(0, task.rewardCoins);
        data.relievePressure(Math.max(0, task.pressureRelief));
        byTask.put(task.id, now + Math.max(0, CruiseConfig.settings.tasks.completionCooldownSeconds));
        setProgress(playerId, task.id, 0);
        ACTIVE_STATION_TASKS.remove(playerId, task.id);
        LinkedHashMap<String, Long> assigned = ASSIGNED_TASKS.get(playerId);
        if (assigned != null) assigned.remove(task.id);
        refillAssignments(playerId, now);
        String name = task.displayName == null || task.displayName.isBlank() ? "日常工作" : task.displayName;
        player.sendSystemMessage(Component.literal("做完了：" + name + "。到账 " + task.rewardCoins
                + " 金币，心情也轻松了些。"));
        return true;
    }

    private static int getProgress(UUID id, String task) {
        return PROGRESS.computeIfAbsent(id, k -> new HashMap<>()).getOrDefault(task, 0);
    }

    private static void setProgress(UUID id, String task, int value) {
        PROGRESS.computeIfAbsent(id, k -> new HashMap<>()).put(task, value);
    }

    public static TaskHudSnapshot hudSnapshot(UUID playerId) {
        String activeId = ACTIVE_STATION_TASKS.get(playerId);
        LinkedHashMap<String, Long> assigned = ASSIGNED_TASKS.get(playerId);
        if (assigned == null || assigned.isEmpty()) return new TaskHudSnapshot("", 0, 0, 0);

        String selectedId = activeId != null && assigned.containsKey(activeId) ? activeId : null;
        if (selectedId == null) {
            selectedId = assigned.entrySet().stream().min(Map.Entry.comparingByValue())
                    .map(Map.Entry::getKey).orElse(null);
        }
        if (selectedId == null) return new TaskHudSnapshot("", 0, 0, 0);
        String taskId = selectedId;
        for (CruiseConfig.TaskDefinition task : CruiseConfig.settings.tasks.tasks) {
            if (task == null || !taskId.equals(task.id)) continue;
            long deadline = assigned.getOrDefault(taskId, tickCount / 20L);
            int remaining = (int) Math.max(0L, deadline - tickCount / 20L);
            return new TaskHudSnapshot(task.displayName, getProgress(playerId, taskId), task.durationSeconds, remaining);
        }
        return new TaskHudSnapshot("", 0, 0, 0);
    }

    /** Kept for interactions that need to validate a food stack before allowing vanilla consumption. */
    public static boolean isFood(ItemStack stack) {
        return stack != null && !stack.isEmpty() && stack.getItem().isEdible();
    }
}

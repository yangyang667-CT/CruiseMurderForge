package com.cruisemurder.task;

import com.cruisemurder.game.MatchManager;
import com.cruisemurder.game.PlayerRoundData;
import com.cruisemurder.game.LightsOutManager;
import com.cruisemurder.config.CruiseConfig;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "cruisemurder")
public final class TaskStationEvents {
    private TaskStationEvents() {}

    @SubscribeEvent
    public static void onStationClick(PlayerInteractEvent.RightClickBlock event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player.level().isClientSide
                || MatchManager.state() != MatchManager.State.ACTIVE) return;
        PlayerRoundData data = MatchManager.data(player.getUUID());
        if (data == null || !data.alive) return;
        if (!"KILLER".equals(data.role) && TaskStationManager.matches("lights_console", player, event.getPos())
                && LightsOutManager.restore(player.getServer())) {
            event.setCanceled(true);
            return;
        }
        if ("KILLER".equals(data.role)) return;
        for (CruiseConfig.TaskDefinition task : CruiseConfig.settings.tasks.tasks) {
            if (task == null || !task.enabled || !"INTERACT_AT_STATION".equals(task.type)
                    || task.station == null || task.station.isBlank()) continue;
            if (TaskStationManager.matches(task.station, player, event.getPos())) {
                if (TaskActivityManager.beginStationTask(player, task.id)) {
                    event.setCanceled(true);
                    return;
                }
                player.sendSystemMessage(Component.literal("现在还不能检修这台设备。"));
                event.setCanceled(true);
                return;
            }
        }
    }
}

package com.cruisemurder.item;

import com.cruisemurder.game.LightsOutManager;
import com.cruisemurder.game.MatchManager;
import com.cruisemurder.game.PlayerRoundData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/** One-use sabotage item that temporarily blacks out the ship for every participant. */
public final class BlackoutItem extends Item {
    public BlackoutItem(Properties properties) { super(properties.stacksTo(1)); }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("右键使用，整艘船会暂时陷入黑暗。"));
        tooltip.add(Component.literal("乘客可以去配电箱提前恢复照明。").withStyle(ChatFormatting.GRAY));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.sidedSuccess(stack, true);
        if (!(player instanceof ServerPlayer serverPlayer)) return InteractionResultHolder.pass(stack);
        PlayerRoundData data = MatchManager.data(serverPlayer.getUUID());
        if (MatchManager.state() != MatchManager.State.ACTIVE || data == null || !data.alive
                || !"KILLER".equals(data.role)) {
            serverPlayer.sendSystemMessage(Component.literal("这东西不该由你来用。"));
            return InteractionResultHolder.fail(stack);
        }
        if (!LightsOutManager.trigger(serverPlayer)) return InteractionResultHolder.fail(stack);
        stack.shrink(1);
        serverPlayer.getCooldowns().addCooldown(this, 20);
        return InteractionResultHolder.sidedSuccess(stack, false);
    }
}

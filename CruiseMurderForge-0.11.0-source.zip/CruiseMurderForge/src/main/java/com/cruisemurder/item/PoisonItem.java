package com.cruisemurder.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import java.util.List;

/** Shop-only item used to poison the configured dining plate. */
public final class PoisonItem extends Item {
    public PoisonItem(Properties properties) { super(properties.stacksTo(16)); }

    @Override
    public boolean isFoil(ItemStack stack) { return true; }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("用在餐盘上，让下一份餐食变得危险。")
                .withStyle(ChatFormatting.DARK_GREEN));
    }
}

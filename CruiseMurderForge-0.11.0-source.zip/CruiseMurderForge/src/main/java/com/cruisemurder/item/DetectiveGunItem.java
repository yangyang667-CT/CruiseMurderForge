package com.cruisemurder.item;

import com.cruisemurder.config.CruiseConfig;
import com.cruisemurder.game.MatchManager;
import com.cruisemurder.game.PlayerRoundData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** Single-use interaction per cooldown window; all hit validation occurs on the server. */
public final class DetectiveGunItem extends Item {
    public DetectiveGunItem(Properties properties) { super(properties.stacksTo(1)); }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("右键开火。每次开枪后都要等冷却。"));
        tooltip.add(Component.literal("误伤会扣金币，手枪也会被收走。").withStyle(ChatFormatting.GRAY));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.sidedSuccess(stack, true);
        if (!(player instanceof ServerPlayer shooter)) return InteractionResultHolder.pass(stack);
        if (MatchManager.state() != MatchManager.State.ACTIVE) {
            shooter.sendSystemMessage(Component.literal("现在还不能开枪。"));
            return InteractionResultHolder.fail(stack);
        }
        PlayerRoundData shooterData = MatchManager.data(shooter.getUUID());
        if (shooterData == null || !shooterData.alive) return InteractionResultHolder.fail(stack);
        if (!stack.hasTag() || !stack.getTag().contains("cruisemurder_ammo")) {
            stack.getOrCreateTag().putInt("cruisemurder_ammo", Math.max(1, CruiseConfig.settings.detective.ammo));
        }
        int ammoLeft = stack.getOrCreateTag().getInt("cruisemurder_ammo");
        if (ammoLeft <= 0) {
            shooter.sendSystemMessage(Component.literal("枪里没子弹了。"));
            return InteractionResultHolder.fail(stack);
        }
        long now = shooter.getServer() == null ? level.getGameTime() : shooter.getServer().overworld().getGameTime();
        long readyAt = stack.getOrCreateTag().getLong("cruisemurder_ready_at");
        if (readyAt > now) {
            int remaining = (int) Math.max(1L, (readyAt - now + 19L) / 20L);
            shooter.sendSystemMessage(Component.literal("枪还没凉下来。再等 " + remaining + " 秒。"));
            return InteractionResultHolder.fail(stack);
        }
        if (shooter.getCooldowns().isOnCooldown(this)) {
            int configured = Math.max(1, CruiseConfig.settings.detective.cooldownSeconds);
            int remaining = Math.max(1, (int) Math.ceil(shooter.getCooldowns().getCooldownPercent(this, 0.0F) * configured));
            shooter.sendSystemMessage(Component.literal("枪还没凉下来。再等 " + remaining + " 秒。"));
            return InteractionResultHolder.fail(stack);
        }

        int cooldownTicks = Math.max(1, CruiseConfig.settings.detective.cooldownSeconds) * 20;
        shooter.getCooldowns().addCooldown(this, cooldownTicks);
        stack.getOrCreateTag().putLong("cruisemurder_ready_at", now + cooldownTicks);
        ammoLeft--;
        stack.getOrCreateTag().putInt("cruisemurder_ammo", ammoLeft);
        double range = Math.max(2.0, CruiseConfig.settings.detective.range);
        Vec3 start = shooter.getEyePosition();
        Vec3 end = start.add(shooter.getViewVector(1.0F).scale(range));
        HitResult blockHit = level.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, shooter));
        if (blockHit.getType() != HitResult.Type.MISS) end = blockHit.getLocation();
        AABB searchBox = shooter.getBoundingBox().expandTowards(end.subtract(start)).inflate(1.0);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(shooter, start, end, searchBox,
                candidate -> isLivingRoundPlayer(candidate, shooter), range * range);

        shooter.sendSystemMessage(Component.literal("砰！枪声在走廊里回荡。剩下 " + ammoLeft + " 发。")
                .withStyle(ChatFormatting.GRAY));
        if (hit == null || !(hit.getEntity() instanceof ServerPlayer target)) {
            shooter.sendSystemMessage(Component.literal("子弹打在了别处。"));
            return InteractionResultHolder.success(stack);
        }
        PlayerRoundData targetData = MatchManager.data(target.getUUID());
        if (targetData == null || !targetData.alive) return InteractionResultHolder.success(stack);

        boolean detective = "DETECTIVE".equals(shooterData.role);
        boolean targetIsKiller = "KILLER".equals(targetData.role);
        if (!targetIsKiller) {
            shooterData.coins = Math.max(0, shooterData.coins - CruiseConfig.settings.detective.wrongShotPenaltyCoins);
            shooter.setItemInHand(hand, ItemStack.EMPTY);
            if (detective) shooterData.role = "CIVILIAN";
            shooter.sendSystemMessage(Component.literal("你打错人了。枪被收走，金币也扣了些。")
                    .withStyle(ChatFormatting.RED));
            target.sendSystemMessage(Component.literal("枪声擦破了耳边的空气……你中弹了！")
                    .withStyle(ChatFormatting.RED));
        } else {
            shooter.sendSystemMessage(Component.literal("目标倒下了。"));
            target.sendSystemMessage(Component.literal("枪声响起，你倒在了地上。")
                    .withStyle(ChatFormatting.RED));
        }

        target.hurt(level.damageSources().playerAttack(shooter), 1000.0F);
        if (target.isAlive()) target.hurt(level.damageSources().magic(), 1000.0F);
        if (target.isAlive()) target.kill();
        return InteractionResultHolder.success(shooter.getItemInHand(hand));
    }

    private static boolean isLivingRoundPlayer(Entity entity, ServerPlayer shooter) {
        if (!(entity instanceof ServerPlayer target) || target == shooter || !target.isAlive()) return false;
        PlayerRoundData data = MatchManager.data(target.getUUID());
        return data != null && data.alive;
    }
}

package com.cruisemurder.item;

import com.cruisemurder.config.CruiseConfig;
import com.cruisemurder.game.MatchManager;
import com.cruisemurder.game.PlayerRoundData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** Hold right-click to ready the knife; releasing after the configured wind-up performs the stab. */
public final class KnifeItem extends Item {
    private static final int VANILLA_USE_LIMIT = 72_000;

    public KnifeItem(Properties properties) {
        super(properties.stacksTo(1));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) {
            player.startUsingItem(hand);
            return InteractionResultHolder.consume(stack);
        }
        if (!(player instanceof ServerPlayer serverPlayer)) return InteractionResultHolder.fail(stack);
        PlayerRoundData data = MatchManager.data(serverPlayer.getUUID());
        if (MatchManager.state() != MatchManager.State.ACTIVE || data == null || !data.alive
                || !"KILLER".equals(data.role)) {
            serverPlayer.sendSystemMessage(Component.literal("这把刀不是你的。"));
            return InteractionResultHolder.fail(stack);
        }
        if (serverPlayer.getCooldowns().isOnCooldown(this)) {
            serverPlayer.sendSystemMessage(Component.literal("还得等一会儿才能再动手。"));
            return InteractionResultHolder.fail(stack);
        }
        serverPlayer.startUsingItem(hand);
        serverPlayer.sendSystemMessage(Component.literal("你握紧了匕首……"));
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return VANILLA_USE_LIMIT;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.SPEAR;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("按住右键蓄力，松开刺出。"));
        tooltip.add(Component.literal("需要杀手身份；过早松手不会命中。").withStyle(ChatFormatting.DARK_RED));
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int timeLeft) {
        if (level.isClientSide || !(entity instanceof ServerPlayer killer)) return;
        PlayerRoundData killerData = MatchManager.data(killer.getUUID());
        if (MatchManager.state() != MatchManager.State.ACTIVE || killerData == null || !killerData.alive
                || !"KILLER".equals(killerData.role)) return;

        int heldTicks = VANILLA_USE_LIMIT - timeLeft;
        int requiredTicks = Math.max(2, (int) Math.ceil(CruiseConfig.settings.knife.holdSeconds * 20.0));
        if (heldTicks < requiredTicks) {
            killer.sendSystemMessage(Component.literal("还没蓄好力。按住右键再松开。"));
            return;
        }
        if (killer.getCooldowns().isOnCooldown(this)) {
            killer.sendSystemMessage(Component.literal("匕首还没准备好。"));
            return;
        }

        int cooldownTicks = Math.max(1, CruiseConfig.settings.knife.cooldownSeconds) * 20;
        killer.getCooldowns().addCooldown(this, cooldownTicks);
        double range = Math.max(1.0, CruiseConfig.settings.knife.range);
        Vec3 start = killer.getEyePosition();
        Vec3 end = start.add(killer.getViewVector(1.0F).scale(range));
        HitResult blockHit = level.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, killer));
        if (blockHit.getType() != HitResult.Type.MISS) end = blockHit.getLocation();
        AABB searchBox = killer.getBoundingBox().expandTowards(end.subtract(start)).inflate(0.6);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(killer, start, end, searchBox,
                candidate -> candidate instanceof ServerPlayer target && target != killer
                        && target.isAlive() && isLivingRoundPlayer(target), range * range);
        if (hit == null || !(hit.getEntity() instanceof ServerPlayer target)) {
            killer.sendSystemMessage(Component.literal("你刺了个空。"));
            return;
        }
        PlayerRoundData targetData = MatchManager.data(target.getUUID());
        if (targetData == null || !targetData.alive || target == killer) return;

        target.sendSystemMessage(Component.literal("你被人从近处袭击了！").withStyle(ChatFormatting.RED));
        killer.sendSystemMessage(Component.literal("你出手了。"));
        target.hurt(level.damageSources().playerAttack(killer), 1000.0F);
        if (target.isAlive()) target.hurt(level.damageSources().magic(), 1000.0F);
        if (target.isAlive()) target.kill();
        if (CruiseConfig.settings.knife.consumeOnKill && !target.isAlive()) stack.shrink(1);
    }

    private static boolean isLivingRoundPlayer(ServerPlayer target) {
        PlayerRoundData data = MatchManager.data(target.getUUID());
        return data != null && data.alive;
    }
}

package com.cruisemurder.item;

import com.cruisemurder.CruiseMurderMod;
import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    private static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, CruiseMurderMod.MODID);
    public static final RegistryObject<Item> DETECTIVE_GUN = ITEMS.register("detective_gun",
            () -> new DetectiveGunItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> KNIFE = ITEMS.register("knife",
            () -> new KnifeItem(new Item.Properties()));
    public static final RegistryObject<Item> POISON_KIT = ITEMS.register("poison_kit",
            () -> new PoisonItem(new Item.Properties()));
    public static final RegistryObject<Item> BLACKOUT_DEVICE = ITEMS.register("blackout_device",
            () -> new BlackoutItem(new Item.Properties()));

    private ModItems() {}
    public static void register(IEventBus bus) { ITEMS.register(bus); }
}

package com.cruisemurder.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraftforge.fml.loading.FMLPaths;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class CruiseConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FMLPaths.CONFIGDIR.get().resolve("cruisemurder-common.json");
    public static Settings settings = Settings.defaults();

    private CruiseConfig() {}

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                Settings loaded = GSON.fromJson(Files.readString(FILE), Settings.class);
                if (loaded != null) settings = loaded;
            }
            settings.sanitize();
            Files.createDirectories(FILE.getParent());
            // Rewrite a normalized config so newly added options appear after an update.
            Files.writeString(FILE, GSON.toJson(settings));
        } catch (IOException | RuntimeException ex) {
            System.err.println("[CruiseMurder] Failed to load config; using defaults: " + ex.getMessage());
            settings = Settings.defaults();
        }
    }

    public static final class Settings {
        public Match match = new Match();
        public Economy economy = new Economy();
        public Pressure pressure = new Pressure();
        public Knife knife = new Knife();
        public Detective detective = new Detective();
        public Tasks tasks = new Tasks();
        public Poison poison = new Poison();
        public Lights lights = new Lights();
        public CorpseCompat corpseCompat = new CorpseCompat();

        public static Settings defaults() { return new Settings(); }
        void sanitize() {
            if (match == null) match = new Match();
            if (economy == null) economy = new Economy();
            if (pressure == null) pressure = new Pressure();
            if (knife == null) knife = new Knife();
            if (detective == null) detective = new Detective();
            if (tasks == null) tasks = new Tasks();
            if (poison == null) poison = new Poison();
            if (lights == null) lights = new Lights();
            if (corpseCompat == null) corpseCompat = new CorpseCompat();
            if (corpseCompat.optionalModId == null || corpseCompat.optionalModId.isBlank()) corpseCompat.optionalModId = "corpse";
            match.minPlayers = clamp(match.minPlayers, 2, 13);
            match.maxPlayers = clamp(match.maxPlayers, match.minPlayers, 13);
            match.roundSeconds = clamp(match.roundSeconds, 60, 7200);
            match.wakeSeconds = clamp(match.wakeSeconds, 1, 120);
            economy.payoutIntervalSeconds = clamp(economy.payoutIntervalSeconds, 1, 3600);
            economy.payoutCoins = clamp(economy.payoutCoins, 0, 10000);
            economy.startingCoins = clamp(economy.startingCoins, 0, 1000000);
            pressure.max = clamp(pressure.max, 1, 1000);
            pressure.hallucinationThreshold = clamp(pressure.hallucinationThreshold, 1, pressure.max);
            if (!Double.isFinite(pressure.increasePerSecond)) pressure.increasePerSecond = 0.15;
            pressure.increasePerSecond = Math.max(0.0, Math.min(10.0, pressure.increasePerSecond));
            knife.price = clamp(knife.price, 0, 1000000);
            knife.cooldownSeconds = clamp(knife.cooldownSeconds, 1, 3600);
            if (!Double.isFinite(knife.holdSeconds)) knife.holdSeconds = 0.8;
            knife.holdSeconds = Math.max(0.1, Math.min(10.0, knife.holdSeconds));
            if (!Double.isFinite(knife.range)) knife.range = 2.5;
            knife.range = Math.max(1.0, Math.min(6.0, knife.range));
            detective.ammo = clamp(detective.ammo, 1, 64);
            detective.cooldownSeconds = clamp(detective.cooldownSeconds, 1, 3600);
            if (!Double.isFinite(detective.range)) detective.range = 18.0;
            detective.range = Math.max(2.0, Math.min(40.0, detective.range));
            detective.wrongShotPenaltyCoins = clamp(detective.wrongShotPenaltyCoins, 0, 1000000);
            poison.price = clamp(poison.price, 0, 1000000);
            lights.blackoutPrice = clamp(lights.blackoutPrice, 0, 1000000);
            lights.blackoutSeconds = clamp(lights.blackoutSeconds, 3, 120);
            lights.cooldownSeconds = clamp(lights.cooldownSeconds, lights.blackoutSeconds, 3600);
            tasks.completionCooldownSeconds = clamp(tasks.completionCooldownSeconds, 0, 3600);
            tasks.refreshSeconds = clamp(tasks.refreshSeconds, 15, 3600);
            tasks.activeTaskCount = clamp(tasks.activeTaskCount, 1, 5);
            tasks.missedTaskPressure = clamp(tasks.missedTaskPressure, 0, pressure.max);
            if (tasks.tasks == null) tasks.tasks = Tasks.defaultTasks();
            java.util.Set<String> seenTaskIds = new java.util.HashSet<>();
            java.util.Set<String> supportedTaskTypes = java.util.Set.of(
                    "SWIM_IN_REGION", "WATCH_IN_REGION", "STAY_IN_REGION", "INTERACT_AT_STATION", "EAT_AT_STATION");
            for (TaskDefinition task : tasks.tasks) {
                if (task == null) continue;
                if (task.id == null) task.id = "";
                task.id = task.id.trim().toLowerCase(java.util.Locale.ROOT);
                if (task.id.isBlank() || !seenTaskIds.add(task.id)) task.enabled = false;
                if (task.type == null) task.type = "";
                task.type = task.type.trim().toUpperCase(java.util.Locale.ROOT);
                if (!supportedTaskTypes.contains(task.type)) task.enabled = false;
                if (task.displayName == null || task.displayName.isBlank()) task.displayName = "日常工作";
                if (task.region == null) task.region = "";
                task.region = task.region.trim().toLowerCase(java.util.Locale.ROOT);
                if (task.station == null) task.station = "";
                task.station = task.station.trim().toLowerCase(java.util.Locale.ROOT);
                task.durationSeconds = clamp(task.durationSeconds, 1, 600);
                task.rewardCoins = clamp(task.rewardCoins, 0, 10000);
                task.pressureRelief = clamp(task.pressureRelief, 0, pressure.max);
            }
        }
        private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
    }
    public static final class Match {
        public int minPlayers = 2, maxPlayers = 13, roundSeconds = 600, wakeSeconds = 10;
        public String spawnMode = "RANDOM_CABIN";
    }
    public static final class Economy {
        public int startingCoins = 50, payoutIntervalSeconds = 60, payoutCoins = 10;
    }
    public static final class Pressure {
        public boolean enabled = true;
        public double increasePerSecond = 0.15;
        public int max = 100, hallucinationThreshold = 70, taskRelief = 25;
    }
    public static final class Knife {
        public int price = 100, cooldownSeconds = 20;
        public double holdSeconds = 0.8, range = 2.5;
        public boolean consumeOnKill = true;
    }
    public static final class Detective {
        public int ammo = 6;
        public int cooldownSeconds = 30;
        public int wrongShotPenaltyCoins = 25;
        public double range = 18.0;
        public String wrongShotPenalty = "DROP_GUN";
    }
    public static final class Poison {
        public int price = 30;
    }
    public static final class Lights {
        public int blackoutPrice = 65;
        public int blackoutSeconds = 12;
        public int cooldownSeconds = 90;
    }
    public static final class CorpseCompat {
        public String optionalModId = "corpse";
        public boolean keepGameItemsOutOfCorpse = true;
    }
    public static final class Tasks {
        public int refreshSeconds = 90, rewardCoins = 15, activeTaskCount = 2;
        public int completionCooldownSeconds = 45;
        public int missedTaskPressure = 15;
        public boolean requireRegions = true;
        public java.util.List<TaskDefinition> tasks = defaultTasks();
        private static java.util.List<TaskDefinition> defaultTasks() {
            java.util.List<TaskDefinition> list = new java.util.ArrayList<>();
            list.add(new TaskDefinition("pool_swim", "SWIM_IN_REGION", "泳池畅游", "pool", "", 8, 15, 25));
            list.add(new TaskDefinition("cinema_movie", "WATCH_IN_REGION", "看完电影", "cinema", "cinema_screen", 20, 20, 30));
            list.add(new TaskDefinition("dining_eat", "EAT_AT_STATION", "餐厅用餐", "dining", "dining_plate", 1, 10, 15));
            list.add(new TaskDefinition("engine_repair", "INTERACT_AT_STATION", "维修动力舱", "engine", "engine_console", 3, 20, 30));
            list.add(new TaskDefinition("deck_air", "STAY_IN_REGION", "甲板透气", "deck", "", 12, 12, 20));
            list.add(new TaskDefinition("lounge_music", "STAY_IN_REGION", "休息室放松", "lounge", "", 15, 12, 20));
            return list;
        }
    }
    public static final class TaskDefinition {
        public String id, type, displayName, region, station;
        public int durationSeconds, rewardCoins, pressureRelief;
        public boolean enabled = true;
        public TaskDefinition() {}
        public TaskDefinition(String id, String type, String displayName, String region, String station,
                              int durationSeconds, int rewardCoins, int pressureRelief) {
            this.id=id; this.type=type; this.displayName=displayName; this.region=region; this.station=station;
            this.durationSeconds=durationSeconds; this.rewardCoins=rewardCoins; this.pressureRelief=pressureRelief;
        }
    }
}

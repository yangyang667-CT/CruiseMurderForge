package com.cruisemurder.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Small in-game storefront; the server remains authoritative for every purchase. */
public final class ShopScreen extends Screen {
    public ShopScreen() {
        super(Component.literal("船上商店"));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int firstY = this.height / 2 - 24;
        ClientHudState.Snapshot state = ClientHudState.current();
        Button knife = Button.builder(
                Component.literal("匕首　·　" + state.knifePrice + " 金币"),
                button -> sendPurchase("knife"))
                .bounds(centerX - 92, firstY, 184, 22).build();
        Button poison = Button.builder(
                Component.literal("餐食毒药　·　" + state.poisonPrice + " 金币"),
                button -> sendPurchase("poison"))
                .bounds(centerX - 92, firstY + 28, 184, 22).build();
        Button blackout = Button.builder(
                Component.literal("断电装置　·　" + state.blackoutPrice + " 金币"),
                button -> sendPurchase("blackout"))
                .bounds(centerX - 92, firstY + 56, 184, 22).build();
        boolean killer = "KILLER".equals(state.role);
        knife.active = killer;
        poison.active = killer;
        blackout.active = killer;
        addRenderableWidget(knife);
        addRenderableWidget(poison);
        addRenderableWidget(blackout);
        addRenderableWidget(Button.builder(Component.literal("离开商店"), button -> onClose())
                .bounds(centerX - 92, firstY + 84, 184, 20).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        int cx = this.width / 2;
        ClientHudState.Snapshot state = ClientHudState.current();
        graphics.fill(cx - 112, this.height / 2 - 94, cx + 112, this.height / 2 + 100, 0xE0181B21);
        graphics.drawCenteredString(this.font, this.title, cx, this.height / 2 - 80, 0xFFFFD66B);
        graphics.drawCenteredString(this.font,
                Component.literal("口袋里有 " + state.coins + " 金币"), cx, this.height / 2 - 59, 0xFFEAEAEA);
        String roleText = switch (state.role) {
            case "KILLER" -> "有些东西，不该让别人看见。";
            case "DETECTIVE" -> "侦探不能购买这些东西。";
            default -> "看看价钱就好，别乱花钱。";
        };
        graphics.drawCenteredString(this.font, Component.literal(roleText), cx, this.height / 2 - 44, 0xFFB8BCC4);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    private static void sendPurchase(String item) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.getConnection() != null) {
            // Purchasing still goes through the server command and its role/coin checks.
            minecraft.getConnection().sendCommand("cruisemurder shop " + item);
        }
        minecraft.setScreen(null);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}

package com.cruisemurder.client;

import com.cruisemurder.CruiseMurderMod;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

/** The shop key is configurable in Minecraft's Controls menu. */
public final class CruiseShopKeybind {
    public static final KeyMapping OPEN_SHOP = new KeyMapping(
            "key.cruisemurder.open_shop", GLFW.GLFW_KEY_B, "key.categories.cruisemurder");

    private CruiseShopKeybind() {}
}

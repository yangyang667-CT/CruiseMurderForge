package com.cruisemurder.client;

import com.cruisemurder.CruiseMurderMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Client-side-only hand-item hallucinations; the server inventory is never modified. */
@Mod.EventBusSubscriber(modid = CruiseMurderMod.MODID, value = Dist.CLIENT)
public final class HallucinationRenderEvents {
    private static final Map<UUID, OriginalHands> ORIGINAL_HANDS = new HashMap<>();
    private static final ItemStack[] FAKE_MAIN_HANDS = {
            new ItemStack(Items.IRON_SWORD), new ItemStack(Items.CROSSBOW),
            new ItemStack(Items.IRON_AXE), new ItemStack(Items.FLINT_AND_STEEL),
            new ItemStack(Items.BLAZE_ROD), new ItemStack(Items.NETHERITE_SWORD)
    };
    private static final ItemStack[] FAKE_OFF_HANDS = {
            ItemStack.EMPTY, new ItemStack(Items.SHIELD), new ItemStack(Items.TOTEM_OF_UNDYING)
    };

    private HallucinationRenderEvents() {}

    @SubscribeEvent
    public static void onPlayerRenderPre(RenderPlayerEvent.Pre event) {
        ClientHudState.Snapshot state = ClientHudState.current();
        Minecraft minecraft = Minecraft.getInstance();
        if (!state.hallucinating || minecraft.level == null) return;
        AbstractClientPlayer player = event.getEntity();
        if (minecraft.player != null && player.getUUID().equals(minecraft.player.getUUID())) return;
        if (ORIGINAL_HANDS.containsKey(player.getUUID())) return;

        ItemStack oldMain = player.getMainHandItem();
        ItemStack oldOff = player.getOffhandItem();
        ORIGINAL_HANDS.put(player.getUUID(), new OriginalHands(oldMain, oldOff));
        long phase = minecraft.level.getGameTime() / 40L;
        int mainIndex = Math.floorMod(player.getUUID().hashCode() + (int) phase, FAKE_MAIN_HANDS.length);
        int offIndex = Math.floorMod(player.getUUID().hashCode() / 7 + (int) phase, FAKE_OFF_HANDS.length);
        player.setItemInHand(InteractionHand.MAIN_HAND, FAKE_MAIN_HANDS[mainIndex].copy());
        player.setItemInHand(InteractionHand.OFF_HAND, FAKE_OFF_HANDS[offIndex].copy());
    }

    @SubscribeEvent
    public static void onPlayerRenderPost(RenderPlayerEvent.Post event) {
        AbstractClientPlayer player = event.getEntity();
        OriginalHands original = ORIGINAL_HANDS.remove(player.getUUID());
        if (original == null) return;
        player.setItemInHand(InteractionHand.MAIN_HAND, original.mainHand());
        player.setItemInHand(InteractionHand.OFF_HAND, original.offHand());
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || ORIGINAL_HANDS.isEmpty()) return;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) {
            ORIGINAL_HANDS.clear();
            return;
        }
        // Safety net in case another renderer cancels between our Pre and Post callbacks.
        for (Map.Entry<UUID, OriginalHands> entry : Map.copyOf(ORIGINAL_HANDS).entrySet()) {
            var player = minecraft.level.getPlayerByUUID(entry.getKey());
            if (player != null) {
                player.setItemInHand(InteractionHand.MAIN_HAND, entry.getValue().mainHand());
                player.setItemInHand(InteractionHand.OFF_HAND, entry.getValue().offHand());
            }
            ORIGINAL_HANDS.remove(entry.getKey());
        }
    }

    private record OriginalHands(ItemStack mainHand, ItemStack offHand) {}
}

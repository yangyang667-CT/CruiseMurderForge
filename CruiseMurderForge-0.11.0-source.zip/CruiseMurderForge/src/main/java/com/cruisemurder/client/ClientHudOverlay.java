package com.cruisemurder.client;

import com.cruisemurder.CruiseMurderMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Locale;

@Mod.EventBusSubscriber(modid = CruiseMurderMod.MODID, value = Dist.CLIENT)
public final class ClientHudOverlay {
    private ClientHudOverlay() {}

    @SubscribeEvent
    public static void render(RenderGuiEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.level == null) return;
        ClientHudState.Snapshot state = ClientHudState.current();
        if (!state.showHud) return;

        GuiGraphics graphics = event.getGuiGraphics();
        int x = 8;
        int y = 8;
        int width = 204;
        int height = state.taskName.isEmpty() ? 72 : 84;

        if (state.lightsOut) {
            graphics.fill(0, 0, event.getWindow().getGuiScaledWidth(), event.getWindow().getGuiScaledHeight(), 0xB8000000);
        }
        if (state.hallucinating) {
            // A subtle visual disturbance; text is drawn afterward to remain readable.
            graphics.fill(0, 0, event.getWindow().getGuiScaledWidth(), event.getWindow().getGuiScaledHeight(), 0x180A0010);
        }
        graphics.fill(x - 4, y - 4, x + width, y + height, 0xA0181B21);

        int roleColor = switch (state.role) {
            case "KILLER" -> 0xFFFF5C5C;
            case "DETECTIVE" -> 0xFF77C7FF;
            default -> 0xFFEAEAEA;
        };
        String role = switch (state.role) {
            case "KILLER" -> "杀手";
            case "DETECTIVE" -> "侦探";
            default -> "乘客";
        };
        graphics.drawString(minecraft.font, Component.literal("身份：" + role), x, y, roleColor, true);
        y += 12;
        graphics.drawString(minecraft.font, Component.literal("金币：" + state.coins), x, y, 0xFFFFD66B, true);
        y += 12;
        String timeText = state.waking ? "客舱门开启：" : "剩余时间：";
        graphics.drawString(minecraft.font, Component.literal(timeText + formatTime(state.secondsRemaining)), x, y, 0xFFEAEAEA, true);
        y += 13;

        if (state.gunAmmo > 0 || "DETECTIVE".equals(state.role)) {
            String gunStatus = state.gunAmmo + " 发子弹";
            if (state.gunCooldownSeconds > 0) gunStatus += " · 冷却 " + state.gunCooldownSeconds + " 秒";
            else if (state.gunAmmo > 0) gunStatus += " · 可以开火";
            graphics.drawString(minecraft.font, Component.literal(gunStatus), x, y, 0xFFFFB0A3, true);
            y += 12;
        }

        if (!"KILLER".equals(state.role)) {
            float ratio = Math.max(0.0F, Math.min(1.0F, state.pressure / state.pressureMax));
            int barWidth = 116;
            graphics.drawString(minecraft.font, Component.literal("压力 " + Math.round(state.pressure)
                    + "/" + state.pressureMax), x, y, state.hallucinating ? 0xFFFF6565 : 0xFFD0D0D0, true);
            graphics.fill(x + 1, y + 10, x + barWidth + 1, y + 17, 0xFF34373D);
            int filled = Math.round(barWidth * ratio);
            if (filled > 0) {
                int color = state.hallucinating ? 0xFFFF4848
                        : state.pressure >= state.pressureThreshold ? 0xFFE59B42 : 0xFF7BBE86;
                graphics.fill(x + 1, y + 10, x + 1 + filled, y + 17, color);
            }
            y += 20;
        }

        if (!state.taskName.isEmpty()) {
            String progress = state.taskDuration > 0
                    ? " " + state.taskProgress + "/" + state.taskDuration + " 秒" : "";
            if (state.taskDeadlineSeconds > 0) progress += " · 截止 " + state.taskDeadlineSeconds + " 秒";
            graphics.drawString(minecraft.font, Component.literal("进度：" + state.taskName + progress),
                    x, y, 0xFFEAEAEA, true);
        }
        if (state.lightsOut) {
            String blackoutText = "灯灭了！去配电箱看看。";
            graphics.drawCenteredString(minecraft.font, Component.literal(blackoutText),
                    event.getWindow().getGuiScaledWidth() / 2, event.getWindow().getGuiScaledHeight() / 2,
                    0xFFEAEAEA);
        }
        if (state.hallucinating) {
            String[] whispers = {"刚才那个人……是不是拿着刀？", "你听见身后有脚步声。", "灯光好像闪了一下。"};
            int index = Math.floorMod((int) (minecraft.level.getGameTime() / 80L), whispers.length);
            String whisper = whispers[index];
            int whisperX = Math.max(4, (event.getWindow().getGuiScaledWidth() - minecraft.font.width(whisper)) / 2);
            graphics.drawString(minecraft.font, Component.literal(whisper), whisperX,
                    event.getWindow().getGuiScaledHeight() - 26, 0xFFFF7777, true);
        }
    }

    private static String formatTime(int seconds) {
        return String.format(Locale.ROOT, "%02d:%02d", seconds / 60, seconds % 60);
    }
}

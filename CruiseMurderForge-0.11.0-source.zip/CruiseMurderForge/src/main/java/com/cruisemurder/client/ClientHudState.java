package com.cruisemurder.client;

import com.cruisemurder.network.HudSyncPacket;

/** Client-only copy of the latest server-approved round HUD data. */
public final class ClientHudState {
    private static Snapshot current = Snapshot.hidden();

    private ClientHudState() {}

    public static void accept(HudSyncPacket packet) {
        current = new Snapshot(packet.showHud, packet.waking, packet.role, packet.coins,
                packet.pressure, packet.pressureMax, packet.pressureThreshold, packet.secondsRemaining,
                packet.hallucinating, packet.taskName, packet.taskProgress, packet.taskDuration,
                packet.taskDeadlineSeconds, packet.gunCooldownSeconds, packet.gunAmmo, packet.knifePrice, packet.poisonPrice,
                packet.blackoutPrice, packet.lightsOut);
    }

    public static Snapshot current() { return current; }

    public static final class Snapshot {
        public final boolean showHud;
        public final boolean waking;
        public final String role;
        public final int coins;
        public final float pressure;
        public final int pressureMax;
        public final int pressureThreshold;
        public final int secondsRemaining;
        public final boolean hallucinating;
        public final String taskName;
        public final int taskProgress;
        public final int taskDuration;
        public final int taskDeadlineSeconds;
        public final int gunCooldownSeconds;
        public final int gunAmmo;
        public final int knifePrice;
        public final int poisonPrice;
        public final int blackoutPrice;
        public final boolean lightsOut;

        private Snapshot(boolean showHud, boolean waking, String role, int coins, float pressure,
                         int pressureMax, int pressureThreshold, int secondsRemaining, boolean hallucinating,
                         String taskName, int taskProgress, int taskDuration, int taskDeadlineSeconds,
                         int gunCooldownSeconds, int gunAmmo, int knifePrice, int poisonPrice,
                         int blackoutPrice, boolean lightsOut) {
            this.showHud = showHud;
            this.waking = waking;
            this.role = role == null ? "CIVILIAN" : role;
            this.coins = coins;
            this.pressure = pressure;
            this.pressureMax = Math.max(1, pressureMax);
            this.pressureThreshold = Math.max(1, pressureThreshold);
            this.secondsRemaining = Math.max(0, secondsRemaining);
            this.hallucinating = hallucinating;
            this.taskName = taskName == null ? "" : taskName;
            this.taskProgress = Math.max(0, taskProgress);
            this.taskDuration = Math.max(0, taskDuration);
            this.taskDeadlineSeconds = Math.max(0, taskDeadlineSeconds);
            this.gunCooldownSeconds = Math.max(0, gunCooldownSeconds);
            this.gunAmmo = Math.max(0, gunAmmo);
            this.knifePrice = Math.max(0, knifePrice);
            this.poisonPrice = Math.max(0, poisonPrice);
            this.blackoutPrice = Math.max(0, blackoutPrice);
            this.lightsOut = lightsOut;
        }

        static Snapshot hidden() { return new Snapshot(false, false, "CIVILIAN", 0, 0, 100, 70, 0, false, "", 0, 0, 0, 0, 0, 100, 30, 65, false); }
    }
}

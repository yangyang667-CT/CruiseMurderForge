package com.cruisemurder.client;

import com.cruisemurder.CruiseMurderMod;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CruiseMurderMod.MODID, value = Dist.CLIENT)
public final class ClientShopEvents {
    private ClientShopEvents() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !CruiseShopKeybind.OPEN_SHOP.consumeClick()) return;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.screen != null || !ClientHudState.current().showHud) return;
        minecraft.setScreen(new ShopScreen());
    }
}

package com.cruisemurder;

import com.cruisemurder.cabin.CabinManager;
import com.cruisemurder.config.CruiseConfig;
import com.cruisemurder.game.MatchManager;
import com.cruisemurder.game.PlayerRoundData;
import com.cruisemurder.item.ModItems;
import com.cruisemurder.network.ModNetwork;
import com.cruisemurder.task.TaskRegionManager;
import com.cruisemurder.task.TaskStationManager;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.StringArgumentType;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(CruiseMurderMod.MODID)
public class CruiseMurderMod {
    public static final String MODID = "cruisemurder";

    public CruiseMurderMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.register(bus);
        ModNetwork.register();
        bus.addListener(this::commonSetup);
        MinecraftForge.EVENT_BUS.register(this);
        CruiseConfig.load();
        TaskRegionManager.load();
        TaskStationManager.load();
        CabinManager.load();
    }

    private void commonSetup(FMLCommonSetupEvent event) {}

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END && event.getServer() != null) {
            MatchManager.tick(event.getServer());
            ModNetwork.tick(event.getServer());
        }
    }

    @SubscribeEvent
    public void registerCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("cruisemurder")
            .then(Commands.literal("start").requires(s -> s.hasPermission(2)).executes(ctx -> {
                boolean ok = MatchManager.start(ctx.getSource().getServer());
                ctx.getSource().sendSuccess(() -> Component.literal(ok
                        ? "各就各位，准备开船。" : "现在还不能开局，请检查玩家人数、客舱配置和上一局状态。"), true);
                return ok ? 1 : 0;
            }))
            .then(Commands.literal("stop").requires(s -> s.hasPermission(2)).executes(ctx -> {
                MatchManager.stop(ctx.getSource().getServer(), "船长宣布本局结束。");
                return 1;
            }))
            .then(Commands.literal("status").executes(ctx -> {
                ctx.getSource().sendSuccess(() -> Component.literal(MatchManager.status()), false);
                return 1;
            }))
            .then(Commands.literal("shop")
                .then(Commands.literal("knife").executes(ctx -> buyKnife(ctx.getSource().getEntity())))
                .then(Commands.literal("poison").executes(ctx -> buyPoison(ctx.getSource().getEntity())))
                .then(Commands.literal("blackout").executes(ctx -> buyBlackout(ctx.getSource().getEntity())))
            )
            .then(Commands.literal("region").requires(s -> s.hasPermission(2))
                .then(Commands.literal("pos1").executes(ctx -> setRegionPos(ctx.getSource().getEntity(), 1)))
                .then(Commands.literal("pos2").executes(ctx -> setRegionPos(ctx.getSource().getEntity(), 2)))
                .then(Commands.literal("create").then(Commands.argument("id", StringArgumentType.word()).executes(ctx -> {
                    if (!(ctx.getSource().getEntity() instanceof ServerPlayer player)) return 0;
                    String result = TaskRegionManager.create(player, StringArgumentType.getString(ctx, "id"));
                    ctx.getSource().sendSuccess(() -> Component.literal(result), false);
                    return 1;
                })))
                .then(Commands.literal("list").executes(ctx -> {
                    ctx.getSource().sendSuccess(() -> Component.literal(TaskRegionManager.list()), false);
                    return 1;
                }))
                .then(Commands.literal("remove").then(Commands.argument("id", StringArgumentType.word()).executes(ctx -> {
                    String id = StringArgumentType.getString(ctx, "id");
                    boolean removed = TaskRegionManager.remove(id);
                    ctx.getSource().sendSuccess(() -> Component.literal(removed ? "已删除区域：" + id : "没有这个区域：" + id), false);
                    return removed ? 1 : 0;
                })))
            )
            .then(Commands.literal("station").requires(s -> s.hasPermission(2))
                .then(Commands.literal("set").then(Commands.argument("id", StringArgumentType.word()).executes(ctx -> {
                    if (!(ctx.getSource().getEntity() instanceof ServerPlayer player)) return 0;
                    String result = TaskStationManager.setLookingAt(player, StringArgumentType.getString(ctx, "id"));
                    ctx.getSource().sendSuccess(() -> Component.literal(result), false);
                    return 1;
                })))
                .then(Commands.literal("list").executes(ctx -> {
                    ctx.getSource().sendSuccess(() -> Component.literal(TaskStationManager.list()), false);
                    return 1;
                }))
                .then(Commands.literal("remove").then(Commands.argument("id", StringArgumentType.word()).executes(ctx -> {
                    String result = TaskStationManager.remove(StringArgumentType.getString(ctx, "id"));
                    ctx.getSource().sendSuccess(() -> Component.literal(result), false);
                    return 1;
                })))
            )
            .then(Commands.literal("cabin").requires(s -> s.hasPermission(2))
                .then(Commands.literal("pos1").executes(ctx -> setCabinPos(ctx.getSource().getEntity(), 1)))
                .then(Commands.literal("pos2").executes(ctx -> setCabinPos(ctx.getSource().getEntity(), 2)))
                .then(Commands.literal("create").then(Commands.argument("id", StringArgumentType.word()).executes(ctx -> {
                    if (!(ctx.getSource().getEntity() instanceof ServerPlayer player)) return 0;
                    String result = CabinManager.create(player, StringArgumentType.getString(ctx, "id"));
                    ctx.getSource().sendSuccess(() -> Component.literal(result), false);
                    return 1;
                })))
                .then(Commands.literal("remove").then(Commands.argument("id", StringArgumentType.word()).executes(ctx -> {
                    String result = CabinManager.remove(StringArgumentType.getString(ctx, "id"));
                    ctx.getSource().sendSuccess(() -> Component.literal(result), false);
                    return 1;
                })))
                .then(Commands.literal("list").executes(ctx -> {
                    ctx.getSource().sendSuccess(() -> Component.literal(CabinManager.list()), false);
                    return 1;
                }))
            )
        );
    }

    private static int buyKnife(net.minecraft.world.entity.Entity entity) {
        if (!(entity instanceof ServerPlayer player)) return 0;
        PlayerRoundData data = MatchManager.data(player.getUUID());
        if (MatchManager.state() != MatchManager.State.ACTIVE || data == null || !data.alive) {
            player.sendSystemMessage(Component.literal("商店现在不营业。"));
            return 0;
        }
        if (!"KILLER".equals(data.role)) {
            player.sendSystemMessage(Component.literal("你看了看价签，还是把东西放了回去。"));
            return 0;
        }
        int price = CruiseConfig.settings.knife.price;
        if (data.coins < price) {
            player.sendSystemMessage(Component.literal("钱还不够。匕首要 " + price + " 金币。"));
            return 0;
        }
        data.coins -= price;
        ItemStack knife = new ItemStack(ModItems.KNIFE.get());
        if (!player.getInventory().add(knife)) player.drop(knife, false);
        player.sendSystemMessage(Component.literal("买好了。按住右键蓄力，松开出手。"));
        return 1;
    }

    private static int buyPoison(net.minecraft.world.entity.Entity entity) {
        if (!(entity instanceof ServerPlayer player)) return 0;
        PlayerRoundData data = MatchManager.data(player.getUUID());
        if (MatchManager.state() != MatchManager.State.ACTIVE || data == null || !data.alive) {
            player.sendSystemMessage(Component.literal("商店现在不营业。"));
            return 0;
        }
        if (!"KILLER".equals(data.role)) {
            player.sendSystemMessage(Component.literal("你看了看价签，还是把东西放了回去。"));
            return 0;
        }
        int price = CruiseConfig.settings.poison.price;
        if (data.coins < price) {
            player.sendSystemMessage(Component.literal("钱还不够。毒药要 " + price + " 金币。"));
            return 0;
        }
        data.coins -= price;
        ItemStack poison = new ItemStack(ModItems.POISON_KIT.get());
        if (!player.getInventory().add(poison)) player.drop(poison, false);
        player.sendSystemMessage(Component.literal("拿着它去餐厅，在餐盘上右键。"));
        return 1;
    }

    private static int buyBlackout(net.minecraft.world.entity.Entity entity) {
        if (!(entity instanceof ServerPlayer player)) return 0;
        PlayerRoundData data = MatchManager.data(player.getUUID());
        if (MatchManager.state() != MatchManager.State.ACTIVE || data == null || !data.alive) {
            player.sendSystemMessage(Component.literal("商店现在不营业。"));
            return 0;
        }
        if (!"KILLER".equals(data.role)) {
            player.sendSystemMessage(Component.literal("你看了看价签，还是把东西放了回去。"));
            return 0;
        }
        int price = CruiseConfig.settings.lights.blackoutPrice;
        if (data.coins < price) {
            player.sendSystemMessage(Component.literal("钱还不够。断电装置要 " + price + " 金币。"));
            return 0;
        }
        data.coins -= price;
        ItemStack device = new ItemStack(ModItems.BLACKOUT_DEVICE.get());
        if (!player.getInventory().add(device)) player.drop(device, false);
        player.sendSystemMessage(Component.literal("断电装置买好了。使用后会短暂熄灯；乘客能去配电箱恢复照明。"));
        return 1;
    }

    private static int setRegionPos(net.minecraft.world.entity.Entity entity, int index) {
        if (!(entity instanceof ServerPlayer player)) return 0;
        TaskRegionManager.setPos(player, index);
        player.sendSystemMessage(Component.literal("记下了区域点 " + index + "：" + player.blockPosition().toShortString()));
        return 1;
    }

    private static int setCabinPos(net.minecraft.world.entity.Entity entity, int index) {
        if (!(entity instanceof ServerPlayer player)) return 0;
        CabinManager.setPos(player, index);
        player.sendSystemMessage(Component.literal("记下了客舱点 " + index + "：" + player.blockPosition().toShortString()));
        return 1;
    }
}

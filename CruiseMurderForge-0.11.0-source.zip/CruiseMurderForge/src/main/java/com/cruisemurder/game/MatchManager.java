package com.cruisemurder.game;

import com.cruisemurder.cabin.CabinManager;
import com.cruisemurder.config.CruiseConfig;
import com.cruisemurder.item.ModItems;
import com.cruisemurder.game.LightsOutManager;
import com.cruisemurder.task.DiningTaskEvents;
import com.cruisemurder.task.TaskActivityManager;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraftforge.registries.RegistryObject;

import java.util.*;

/** Server-authoritative round, role, score, pressure, and win-state manager. */
public final class MatchManager {
    public enum State { LOBBY, WAKING, ACTIVE, ENDED }
    private static State state = State.LOBBY;
    private static int elapsedTicks;
    private static final Map<UUID, PlayerRoundData> PLAYERS = new HashMap<>();
    private static long lastPayoutSecond = -1;
    private static final Set<UUID> warnedHallucinating = new HashSet<>();

    private MatchManager() {}

    public static State state() { return state; }
    public static PlayerRoundData data(UUID id) { return PLAYERS.get(id); }
    public static Collection<PlayerRoundData> allData() { return Collections.unmodifiableCollection(PLAYERS.values()); }

    public static boolean start(MinecraftServer server) {
        if (state == State.WAKING || state == State.ACTIVE) return false;
        List<ServerPlayer> roundPlayers = new ArrayList<>(server.getPlayerList().getPlayers());
        CruiseConfig.Settings cfg = CruiseConfig.settings;
        if (roundPlayers.size() < cfg.match.minPlayers || roundPlayers.size() > cfg.match.maxPlayers) return false;
        // A round must not begin unless every participant has a valid, unique cabin destination.
        if (!CabinManager.canAssign(server, roundPlayers.size())) return false;

        Map<UUID, GameType> originalModes = new HashMap<>();
        for (ServerPlayer player : roundPlayers) {
            PlayerRoundData previous = PLAYERS.get(player.getUUID());
            GameType mode = previous == null ? player.gameMode.getGameModeForPlayer() : previous.originalGameMode;
            originalModes.put(player.getUUID(), mode);
            clearGameItems(player);
            // Everyone is a real participant during the round, even if an operator was building in Creative.
            player.setGameMode(GameType.SURVIVAL);
        }

        PLAYERS.clear();
        warnedHallucinating.clear();
        Collections.shuffle(roundPlayers);
        for (ServerPlayer player : roundPlayers) {
            PlayerRoundData data = new PlayerRoundData(player.getUUID(), cfg.economy.startingCoins);
            data.originalGameMode = originalModes.getOrDefault(player.getUUID(), GameType.SURVIVAL);
            PLAYERS.put(player.getUUID(), data);
        }

        ServerPlayer killer = roundPlayers.get(0);
        PLAYERS.get(killer.getUUID()).role = "KILLER";
        if (roundPlayers.size() >= 5) PLAYERS.get(roundPlayers.get(1).getUUID()).role = "DETECTIVE";

        boolean cabinsPlaced = CabinManager.count() >= roundPlayers.size()
                && CabinManager.assignAndTeleport(server, roundPlayers);
        elapsedTicks = 0;
        lastPayoutSecond = -1;
        TaskActivityManager.resetRound();
        DiningTaskEvents.resetRound();
        LightsOutManager.resetRound();
        state = State.WAKING;
        TaskActivityManager.assignInitialTasks(server);

        for (ServerPlayer player : roundPlayers) {
            PlayerRoundData data = PLAYERS.get(player.getUUID());
            if (cabinsPlaced) player.sendSystemMessage(Component.literal("你在自己的客舱里醒来。"));
            else player.sendSystemMessage(Component.literal("客舱安排出了点问题。先待在这里，找管理员处理一下。"));
            switch (data.role) {
                case "KILLER" -> player.sendSystemMessage(Component.literal("你是杀手。匕首需要自己买，按住右键蓄力，松开出手。"));
                case "DETECTIVE" -> {
                    ItemStack gun = new ItemStack(ModItems.DETECTIVE_GUN.get());
                    gun.getOrCreateTag().putInt("cruisemurder_ammo", Math.max(1, cfg.detective.ammo));
                    if (!player.getInventory().add(gun)) player.drop(gun, false);
                    player.sendSystemMessage(Component.literal("你是侦探。枪已经交给你了；每次开枪后要等 "
                            + cfg.detective.cooldownSeconds + " 秒。看准了再扣扳机。"));
                }
                default -> player.sendSystemMessage(Component.literal("你是乘客。把工作做完，留意船上的动静。"));
            }
            if (!"KILLER".equals(data.role)) {
                player.sendSystemMessage(Component.literal("左上角会显示你的工作和期限，别拖太久。"));
            }
        }
        broadcast(server, "船马上就要开了。趁这会儿待在客舱里。" );
        return true;
    }

    public static void stop(MinecraftServer server, String reason) {
        if (state == State.LOBBY || state == State.ENDED) return;
        finishRound(server, reason);
    }

    public static void tick(MinecraftServer server) {
        if (state != State.WAKING && state != State.ACTIVE) return;
        elapsedTicks++;
        CruiseConfig.Settings cfg = CruiseConfig.settings;
        if (state == State.WAKING) {
            if (elapsedTicks >= Math.max(1, cfg.match.wakeSeconds) * 20) {
                state = State.ACTIVE;
                elapsedTicks = 0;
                lastPayoutSecond = -1;
                broadcast(server, "客舱门开了。该做什么，就抓紧去做吧。" );
                checkWinConditions(server);
            }
            return;
        }

        long seconds = elapsedTicks / 20L;
        if (seconds >= cfg.match.roundSeconds) {
            finishRound(server, "时间到了！杀手没能得手，乘客们赢了。" );
            return;
        }

        if (seconds > 0 && seconds % cfg.economy.payoutIntervalSeconds == 0 && seconds != lastPayoutSecond) {
            lastPayoutSecond = seconds;
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                PlayerRoundData data = PLAYERS.get(player.getUUID());
                if (data != null && data.alive) data.coins += cfg.economy.payoutCoins;
            }
            broadcast(server, "工资到账了。" );
        }

        TaskActivityManager.tick(server);
        LightsOutManager.tick(server);
        if (cfg.pressure.enabled) {
            for (PlayerRoundData data : PLAYERS.values()) {
                if (!data.alive || "KILLER".equals(data.role)) continue;
                data.pressure = Math.min(cfg.pressure.max,
                        data.pressure + Math.max(0.0, cfg.pressure.increasePerSecond) / 20.0);
                boolean hallucinating = data.hallucinating(cfg.pressure.hallucinationThreshold);
                if (hallucinating && warnedHallucinating.add(data.playerId)) {
                    ServerPlayer affected = server.getPlayerList().getPlayer(data.playerId);
                    if (affected != null) affected.sendSystemMessage(Component.literal("你开始觉得周围有些不对劲……找点事做，让自己冷静下来。"));
                } else if (!hallucinating) {
                    warnedHallucinating.remove(data.playerId);
                }
            }
        }
    }

    public static void onPlayerDeath(MinecraftServer server, ServerPlayer victim) {
        if (state != State.ACTIVE && state != State.WAKING) return;
        PlayerRoundData dead = PLAYERS.get(victim.getUUID());
        if (dead == null || !dead.alive) return;
        dead.alive = false;
        warnedHallucinating.remove(victim.getUUID());
        broadcast(server, "走廊里出事了！有人倒下了。" );
        // Let the cabin phase finish before checking the roster, then resolve the round once ACTIVE begins.
        if (state == State.ACTIVE) checkWinConditions(server);
    }

    private static void checkWinConditions(MinecraftServer server) {
        boolean killerAlive = false;
        int livingPassengers = 0;
        for (PlayerRoundData data : PLAYERS.values()) {
            if (!data.alive) continue;
            if ("KILLER".equals(data.role)) killerAlive = true;
            else livingPassengers++;
        }
        if (!killerAlive) finishRound(server, "杀手倒下了。乘客们赢了！" );
        else if (livingPassengers == 0) finishRound(server, "船上已经没人能拦住杀手了。杀手获胜。" );
    }

    private static void finishRound(MinecraftServer server, String message) {
        if (state == State.ENDED || state == State.LOBBY) return;
        state = State.ENDED;
        broadcast(server, message);
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            PlayerRoundData data = PLAYERS.get(player.getUUID());
            if (data == null || player.isDeadOrDying()) continue;
            clearGameItems(player);
            player.setGameMode(data.originalGameMode);
        }
        warnedHallucinating.clear();
        TaskActivityManager.resetRound();
        DiningTaskEvents.resetRound();
        LightsOutManager.resetRound();
    }

    public static void onPlayerLogout(MinecraftServer server, ServerPlayer player) {
        PlayerRoundData data = PLAYERS.get(player.getUUID());
        if (data == null || !data.alive || (state != State.WAKING && state != State.ACTIVE)) return;
        data.alive = false;
        warnedHallucinating.remove(player.getUUID());
        broadcast(server, "有位乘客离开了船。" );
        if (state == State.ACTIVE) checkWinConditions(server);
    }

    public static void onPlayerLogin(ServerPlayer player) {
        PlayerRoundData data = PLAYERS.get(player.getUUID());
        if (data == null) return;
        clearGameItems(player);
        if ((state == State.WAKING || state == State.ACTIVE) && !data.alive) {
            player.setGameMode(GameType.SPECTATOR);
        } else if (state == State.ENDED || state == State.LOBBY) {
            player.setGameMode(data.originalGameMode);
        }
    }

    public static void onPlayerRespawn(ServerPlayer player) {
        PlayerRoundData data = PLAYERS.get(player.getUUID());
        if (data == null) return;
        clearGameItems(player);
        if (!data.alive && (state == State.ACTIVE || state == State.WAKING)) {
            player.setGameMode(GameType.SPECTATOR);
        } else {
            player.setGameMode(data.originalGameMode);
        }
    }

    private static void clearGameItems(ServerPlayer player) {
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (stack.isEmpty()) continue;
            if (stack.is(ModItems.KNIFE.get()) || stack.is(ModItems.DETECTIVE_GUN.get())
                    || stack.is(ModItems.POISON_KIT.get())
                    || stack.is(ModItems.BLACKOUT_DEVICE.get())
                    || (stack.hasTag() && stack.getTag().getBoolean("cruisemurder_meal"))) {
                player.getInventory().setItem(i, ItemStack.EMPTY);
            }
        }
    }

    public static boolean completeTask(UUID playerId) {
        PlayerRoundData data = PLAYERS.get(playerId);
        if (state != State.ACTIVE || data == null || !data.alive) return false;
        data.taskCompletions++;
        data.coins += CruiseConfig.settings.tasks.rewardCoins;
        data.relievePressure(CruiseConfig.settings.pressure.taskRelief);
        return true;
    }

    public static int secondsRemaining() {
        if (state == State.WAKING) return Math.max(0, CruiseConfig.settings.match.wakeSeconds - elapsedTicks / 20);
        if (state == State.ACTIVE) return Math.max(0, CruiseConfig.settings.match.roundSeconds - elapsedTicks / 20);
        return 0;
    }

    public static String status() {
        int alive = 0;
        for (PlayerRoundData data : PLAYERS.values()) if (data.alive) alive++;
        String stateText = switch (state) {
            case LOBBY -> "等待开局";
            case WAKING -> "客舱准备中";
            case ACTIVE -> "进行中";
            case ENDED -> "已结束";
        };
        return "本局状态：" + stateText + "；存活玩家 " + alive + "/" + PLAYERS.size()
                + "；已进行 " + (elapsedTicks / 20) + " 秒";
    }

    private static void broadcast(MinecraftServer server, String text) {
        server.getPlayerList().broadcastSystemMessage(Component.literal(text), false);
    }
}

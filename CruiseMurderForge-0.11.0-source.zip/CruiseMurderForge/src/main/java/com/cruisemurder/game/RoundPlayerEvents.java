package com.cruisemurder.game;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import com.cruisemurder.config.CruiseConfig;
import com.cruisemurder.item.ModItems;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "cruisemurder")
public final class RoundPlayerEvents {
    private RoundPlayerEvents() {}

    /**
     * When the optional Corpse mod is installed, move minigame equipment out of the
     * player's inventory before Corpse captures the ordinary inventory. The gear
     * remains lootable on the floor beside the body, including the detective's gun.
     */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void keepRoundGearOutOfCorpse(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player.level().isClientSide) return;
        CruiseConfig.CorpseCompat compat = CruiseConfig.settings.corpseCompat;
        if (compat == null || !compat.keepGameItemsOutOfCorpse
                || compat.optionalModId == null || !ModList.get().isLoaded(compat.optionalModId)) return;

        for (int slot = 0; slot < player.getInventory().getContainerSize(); slot++) {
            ItemStack stack = player.getInventory().getItem(slot);
            if (!isRoundItem(stack)) continue;
            ItemStack drop = stack.copy();
            player.getInventory().setItem(slot, ItemStack.EMPTY);
            player.drop(drop, false);
        }
    }

    private static boolean isRoundItem(ItemStack stack) {
        return !stack.isEmpty() && (stack.is(ModItems.KNIFE.get())
                || stack.is(ModItems.DETECTIVE_GUN.get())
                || stack.is(ModItems.POISON_KIT.get())
                || stack.is(ModItems.BLACKOUT_DEVICE.get())
                || (stack.hasTag() && stack.getTag().getBoolean("cruisemurder_meal")));
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && player.getServer() != null) {
            MatchManager.onPlayerDeath(player.getServer(), player);
        }
    }


    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && player.getServer() != null) {
            MatchManager.onPlayerLogout(player.getServer(), player);
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) MatchManager.onPlayerLogin(player);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) MatchManager.onPlayerRespawn(player);
    }
}

package com.cruisemurder.game;

import com.cruisemurder.config.CruiseConfig;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/** Server-authoritative temporary blackout. Time is based on the overworld game clock. */
public final class LightsOutManager {
    private static long activeUntil;
    private static long nextAllowedAt;

    private LightsOutManager() {}

    public static boolean isActive(MinecraftServer server) {
        return server != null && server.overworld().getGameTime() < activeUntil;
    }

    public static boolean trigger(ServerPlayer killer) {
        MinecraftServer server = killer.getServer();
        if (server == null) return false;
        long now = server.overworld().getGameTime();
        if (isActive(server)) {
            killer.sendSystemMessage(Component.literal("灯已经灭了。别在这时候重复折腾。"));
            return false;
        }
        if (now < nextAllowedAt) {
            long seconds = Math.max(1L, (nextAllowedAt - now + 19L) / 20L);
            killer.sendSystemMessage(Component.literal("断电装置还没充好。再等 " + seconds + " 秒。"));
            return false;
        }
        int durationTicks = Math.max(3, CruiseConfig.settings.lights.blackoutSeconds) * 20;
        activeUntil = now + durationTicks;
        nextAllowedAt = now + Math.max(durationTicks,
                CruiseConfig.settings.lights.cooldownSeconds * 20L);
        server.getPlayerList().broadcastSystemMessage(Component.literal("啪的一声，整艘船陷入黑暗！"), false);
        return true;
    }

    public static boolean restore(MinecraftServer server) {
        if (server == null || !isActive(server)) return false;
        activeUntil = 0;
        server.getPlayerList().broadcastSystemMessage(Component.literal("配电箱重新合闸，灯光亮了起来。"), false);
        return true;
    }

    public static void tick(MinecraftServer server) {
        if (server != null && activeUntil > 0 && server.overworld().getGameTime() >= activeUntil) {
            activeUntil = 0;
            server.getPlayerList().broadcastSystemMessage(Component.literal("灯光闪了几下，终于恢复了。"), false);
        }
    }

    public static void resetRound() {
        activeUntil = 0;
        nextAllowedAt = 0;
    }
}

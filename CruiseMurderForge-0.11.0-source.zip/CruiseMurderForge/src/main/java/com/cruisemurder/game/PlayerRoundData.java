package com.cruisemurder.game;

import java.util.UUID;
import net.minecraft.world.level.GameType;

public final class PlayerRoundData {
    public final UUID playerId;
    public String role = "CIVILIAN";
    public boolean alive = true;
    public int coins;
    public double pressure;
    public int taskCompletions;
    public GameType originalGameMode = GameType.SURVIVAL;
    public PlayerRoundData(UUID playerId, int startingCoins) {
        this.playerId = playerId;
        this.coins = startingCoins;
    }
    public boolean hallucinating(int threshold) { return alive && pressure >= threshold; }
    public void relievePressure(int amount) { pressure = Math.max(0, pressure - Math.max(0, amount)); }
}

package com.cruisemurder.network;

import com.cruisemurder.CruiseMurderMod;
import com.cruisemurder.config.CruiseConfig;
import com.cruisemurder.game.MatchManager;
import com.cruisemurder.game.LightsOutManager;
import com.cruisemurder.game.PlayerRoundData;
import com.cruisemurder.item.ModItems;
import net.minecraft.world.item.ItemStack;
import com.cruisemurder.task.TaskHudSnapshot;
import com.cruisemurder.task.TaskActivityManager;
import net.minecraftforge.network.NetworkDirection;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "5";
    private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(CruiseMurderMod.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);
    private static int tickCounter;
    private static boolean registered;

    private ModNetwork() {}

    public static void register() {
        if (registered) return;
        CHANNEL.registerMessage(0, HudSyncPacket.class, HudSyncPacket::encode, HudSyncPacket::decode,
                HudSyncPacket::handle, java.util.Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        registered = true;
    }

    public static void tick(MinecraftServer server) {
        tickCounter++;
        if (tickCounter % 20 != 0) return;
        for (ServerPlayer player : server.getPlayerList().getPlayers()) sendHud(player);
    }

    public static void sendHud(ServerPlayer player) {
        CruiseConfig.Settings cfg = CruiseConfig.settings;
        PlayerRoundData data = MatchManager.data(player.getUUID());
        boolean inRound = data != null && (MatchManager.state() == MatchManager.State.WAKING
                || MatchManager.state() == MatchManager.State.ACTIVE);
        if (!inRound) {
            CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                    new HudSyncPacket(false, false, "CIVILIAN", 0, 0, 100, 70, 0, false, "", 0, 0, 0,
                            0, 0, cfg.knife.price, cfg.poison.price, cfg.lights.blackoutPrice, false));
            return;
        }

        TaskHudSnapshot task = TaskActivityManager.hudSnapshot(player.getUUID());
        int gunCooldown = 0;
        int gunAmmo = 0;
        long now = player.getServer() == null ? player.level().getGameTime() : player.getServer().overworld().getGameTime();
        for (int slot = 0; slot < player.getInventory().getContainerSize(); slot++) {
            ItemStack stack = player.getInventory().getItem(slot);
            if (stack.isEmpty() || !stack.is(ModItems.DETECTIVE_GUN.get())) continue;
            var tag = stack.getTag();
            gunAmmo = tag != null && tag.contains("cruisemurder_ammo")
                    ? Math.max(0, tag.getInt("cruisemurder_ammo")) : Math.max(1, cfg.detective.ammo);
            long readyAt = tag != null && tag.contains("cruisemurder_ready_at")
                    ? tag.getLong("cruisemurder_ready_at") : 0L;
            gunCooldown = (int) Math.max(0L, (readyAt - now + 19L) / 20L);
            break;
        }
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new HudSyncPacket(
                true,
                MatchManager.state() == MatchManager.State.WAKING,
                data.role,
                data.coins,
                (float) data.pressure,
                cfg.pressure.max,
                cfg.pressure.hallucinationThreshold,
                MatchManager.secondsRemaining(),
                data.hallucinating(cfg.pressure.hallucinationThreshold),
                task.name(), task.progress(), task.duration(), task.secondsUntilDeadline(), gunCooldown, gunAmmo,
                cfg.knife.price, cfg.poison.price, cfg.lights.blackoutPrice,
                LightsOutManager.isActive(player.getServer())));
    }
}

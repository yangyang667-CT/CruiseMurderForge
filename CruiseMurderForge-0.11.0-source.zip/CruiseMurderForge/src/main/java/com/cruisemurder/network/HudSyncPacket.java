package com.cruisemurder.network;

import com.cruisemurder.client.ClientHudState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Small server-authoritative snapshot used by the client HUD. */
public final class HudSyncPacket {
    public final boolean showHud;
    public final boolean waking;
    public final String role;
    public final int coins;
    public final float pressure;
    public final int pressureMax;
    public final int pressureThreshold;
    public final int secondsRemaining;
    public final boolean hallucinating;
    public final String taskName;
    public final int taskProgress;
    public final int taskDuration;
    public final int taskDeadlineSeconds;
    public final int gunCooldownSeconds;
    public final int gunAmmo;
    public final int knifePrice;
    public final int poisonPrice;
    public final int blackoutPrice;
    public final boolean lightsOut;

    public HudSyncPacket(boolean showHud, boolean waking, String role, int coins, float pressure,
                         int pressureMax, int pressureThreshold, int secondsRemaining,
                         boolean hallucinating, String taskName, int taskProgress, int taskDuration,
                         int taskDeadlineSeconds, int gunCooldownSeconds, int gunAmmo, int knifePrice, int poisonPrice,
                         int blackoutPrice, boolean lightsOut) {
        this.showHud = showHud;
        this.waking = waking;
        this.role = role == null ? "CIVILIAN" : role;
        this.coins = coins;
        this.pressure = pressure;
        this.pressureMax = Math.max(1, pressureMax);
        this.pressureThreshold = Math.max(1, pressureThreshold);
        this.secondsRemaining = Math.max(0, secondsRemaining);
        this.hallucinating = hallucinating;
        this.taskName = taskName == null ? "" : taskName;
        this.taskProgress = Math.max(0, taskProgress);
        this.taskDuration = Math.max(0, taskDuration);
        this.taskDeadlineSeconds = Math.max(0, taskDeadlineSeconds);
        this.gunCooldownSeconds = Math.max(0, gunCooldownSeconds);
        this.gunAmmo = Math.max(0, gunAmmo);
        this.knifePrice = Math.max(0, knifePrice);
        this.poisonPrice = Math.max(0, poisonPrice);
        this.blackoutPrice = Math.max(0, blackoutPrice);
        this.lightsOut = lightsOut;
    }

    public static void encode(HudSyncPacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.showHud);
        buf.writeBoolean(msg.waking);
        buf.writeUtf(msg.role, 32);
        buf.writeInt(msg.coins);
        buf.writeFloat(msg.pressure);
        buf.writeInt(msg.pressureMax);
        buf.writeInt(msg.pressureThreshold);
        buf.writeInt(msg.secondsRemaining);
        buf.writeBoolean(msg.hallucinating);
        buf.writeUtf(msg.taskName, 128);
        buf.writeInt(msg.taskProgress);
        buf.writeInt(msg.taskDuration);
        buf.writeInt(msg.taskDeadlineSeconds);
        buf.writeInt(msg.gunCooldownSeconds);
        buf.writeInt(msg.gunAmmo);
        buf.writeInt(msg.knifePrice);
        buf.writeInt(msg.poisonPrice);
        buf.writeInt(msg.blackoutPrice);
        buf.writeBoolean(msg.lightsOut);
    }

    public static HudSyncPacket decode(FriendlyByteBuf buf) {
        return new HudSyncPacket(buf.readBoolean(), buf.readBoolean(), buf.readUtf(32), buf.readInt(),
                buf.readFloat(), buf.readInt(), buf.readInt(), buf.readInt(), buf.readBoolean(),
                buf.readUtf(128), buf.readInt(), buf.readInt(), buf.readInt(), buf.readInt(), buf.readInt(), buf.readInt(), buf.readInt(), buf.readInt(), buf.readBoolean());
    }

    public static void handle(HudSyncPacket msg, Supplier<NetworkEvent.Context> context) {
        context.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientHudState.accept(msg)));
        context.get().setPacketHandled(true);
    }
}

package com.cruisemurder.cabin;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraftforge.fml.loading.FMLPaths;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** Persistent named cabin spawn points. One player is assigned to each cabin per round. */
public final class CabinManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FMLPaths.CONFIGDIR.get().resolve("cruisemurder-cabins.json");
    private static final Map<String, Cabin> CABINS = new LinkedHashMap<>();
    private static final Map<UUID, BlockPos> POS1 = new HashMap<>(), POS2 = new HashMap<>();
    private static final Map<UUID, String> POS1_DIM = new HashMap<>(), POS2_DIM = new HashMap<>();
    private CabinManager() {}

    public static void load() {
        if (!Files.exists(FILE)) return;
        try {
            Type type = new TypeToken<List<Cabin>>(){}.getType();
            List<Cabin> loaded = GSON.fromJson(Files.readString(FILE), type);
            CABINS.clear();
            if (loaded != null) for (Cabin cabin : loaded) {
                if (cabin == null || cabin.id == null || cabin.dimension == null) continue;
                cabin.id = cabin.id.trim().toLowerCase(Locale.ROOT);
                if (!cabin.id.isBlank()) CABINS.put(cabin.id, cabin);
            }
        } catch (Exception e) { System.err.println("[CruiseMurder] Failed loading cabins: " + e.getMessage()); }
    }
    private static void save() {
        try { Files.createDirectories(FILE.getParent()); Files.writeString(FILE, GSON.toJson(CABINS.values())); }
        catch (IOException e) { System.err.println("[CruiseMurder] Failed saving cabins: " + e.getMessage()); }
    }
    public static void setPos(ServerPlayer p, int n) {
        UUID id = p.getUUID();
        String dimension = p.serverLevel().dimension().location().toString();
        if (n == 1) {
            POS1.put(id, p.blockPosition());
            POS1_DIM.put(id, dimension);
        } else {
            POS2.put(id, p.blockPosition());
            POS2_DIM.put(id, dimension);
        }
    }

    public static String create(ServerPlayer p, String rawId) {
        String id = rawId.toLowerCase(Locale.ROOT);
        UUID playerId = p.getUUID();
        BlockPos a=POS1.get(playerId), b=POS2.get(playerId);
        if (a == null || b == null) return "请先设置 pos1 和 pos2。";
        String currentDimension = p.serverLevel().dimension().location().toString();
        if (!currentDimension.equals(POS1_DIM.get(playerId)) || !currentDimension.equals(POS2_DIM.get(playerId))) {
            return "客舱的两个选点必须在同一个维度里。";
        }
        // Spawn near the center of the selected room, with a safe floor-level Y.
        BlockPos spawn = new BlockPos((a.getX()+b.getX())/2, Math.min(a.getY(),b.getY()) + 1, (a.getZ()+b.getZ())/2);
        CABINS.put(id, new Cabin(id, p.serverLevel().dimension().location().toString(), spawn.getX()+0.5, spawn.getY(), spawn.getZ()+0.5, p.getYRot()));
        save(); return "已保存客舱 " + id + "，出生点=" + spawn.toShortString();
    }
    public static String remove(String id) { if (CABINS.remove(id.toLowerCase(Locale.ROOT)) == null) return "找不到该客舱。"; save(); return "已删除客舱 " + id; }
    public static String list() {
        if (CABINS.isEmpty()) return "尚未配置客舱。请用 /cruisemurder cabin pos1、pos2、create <id> 创建。";
        StringBuilder b=new StringBuilder("已配置客舱：");
        for (Cabin c:CABINS.values()) b.append("\n- ").append(c.id).append(" @ ").append(c.dimension).append(" ").append((int)c.x).append(" ").append((int)c.y).append(" ").append((int)c.z);
        return b.toString();
    }
    private record Destination(Cabin cabin, ServerLevel level) {}

    private static List<Destination> validDestinations(MinecraftServer server) {
        List<Destination> valid = new ArrayList<>();
        for (Cabin cabin : CABINS.values()) {
            if (cabin == null || cabin.dimension == null) continue;
            ResourceLocation dimensionId = ResourceLocation.tryParse(cabin.dimension);
            if (dimensionId == null) continue;
            ResourceKey<Level> key = ResourceKey.create(Registries.DIMENSION, dimensionId);
            ServerLevel level = server.getLevel(key);
            if (level == null || !hasSafeSpawn(level, cabin)) continue;
            String locationKey = cabin.dimension + ":" + cabin.x + ":" + cabin.y + ":" + cabin.z;
            boolean duplicate = valid.stream().anyMatch(existing -> {
                Cabin other = existing.cabin();
                String otherKey = other.dimension + ":" + other.x + ":" + other.y + ":" + other.z;
                return locationKey.equals(otherKey);
            });
            if (!duplicate) valid.add(new Destination(cabin, level));
        }
        return valid;
    }

    private static boolean hasSafeSpawn(ServerLevel level, Cabin cabin) {
        BlockPos feet = BlockPos.containing(cabin.x, cabin.y, cabin.z);
        BlockPos head = feet.above();
        BlockPos floor = feet.below();
        return level.getBlockState(feet).getCollisionShape(level, feet).isEmpty()
                && level.getBlockState(head).getCollisionShape(level, head).isEmpty()
                && !level.getBlockState(floor).getCollisionShape(level, floor).isEmpty();
    }

    /** Validate the whole roster before changing player modes or beginning a round. */
    public static boolean canAssign(MinecraftServer server, int playerCount) {
        return playerCount > 0 && validDestinations(server).size() >= playerCount;
    }

    public static boolean assignAndTeleport(MinecraftServer server, List<ServerPlayer> players) {
        List<Destination> destinations = validDestinations(server);
        if (destinations.size() < players.size()) return false;
        Collections.shuffle(destinations);
        List<ServerPlayer> shuffled = new ArrayList<>(players);
        Collections.shuffle(shuffled);
        // Validate every selected destination above before moving any player, preventing partial teleports.
        for (int i = 0; i < shuffled.size(); i++) {
            Destination destination = destinations.get(i);
            Cabin cabin = destination.cabin();
            shuffled.get(i).teleportTo(destination.level(), cabin.x, cabin.y, cabin.z,
                    Set.of(), cabin.yaw, 0.0F);
        }
        return true;
    }

    public static int count() { return CABINS.size(); }
    public static final class Cabin {
        public String id, dimension; public double x,y,z; public float yaw;
        public Cabin(String id,String dimension,double x,double y,double z,float yaw) { this.id=id;this.dimension=dimension;this.x=x;this.y=y;this.z=z;this.yaw=yaw; }
    }
}

# 游轮地图配置

所有区域、客舱和站点都保存在服务端 `config/` 目录，重启后仍会保留。

## 1. 建立任务区域

站到区域的一个角上执行 `/cruisemurder region pos1`，再站到对角执行 `/cruisemurder region pos2`，然后建立区域，例如：

```text
/cruisemurder region create pool
/cruisemurder region create cinema
/cruisemurder region create dining
/cruisemurder region create engine
/cruisemurder region create deck
/cruisemurder region create lounge
```

区域是包含首尾坐标的长方体。同一个区域内可以放多个方块和装饰；任务范围由 `cruisemurder-common.json` 中每项任务的 `region` 决定。

## 2. 设置固定互动站点

对准要互动的方块（例如餐盘下方的方块或动力舱控制台），执行：

```text
/cruisemurder station set dining_plate
/cruisemurder station set engine_console
/cruisemurder station set cinema_screen
/cruisemurder station set lights_console
/cruisemurder station list
```

`dining_plate` 设好后，只有在这个方块上右键才能取餐或下毒。杀手通过 `/cruisemurder shop poison` 买到毒药后，手持毒药对餐盘右键；餐盘的下一份餐食会带毒，之后毒性自动清除。若没有配置 `dining_plate`，旧的 `dining` 区域内任意方块仍可作为临时替代。

`engine_console` 用于动力舱维修任务。乘客右键开始维修，随后需要留在控制台附近直到任务计时结束；离开范围会中断维修。

`lights_console` 是关灯后的配电箱。杀手可在 B 键商店购买断电装置，右键使用后默认熄灯 12 秒；乘客或侦探在熄灯时对配电箱右键可提前恢复照明。当前关灯采用客户端屏幕变暗效果，不会改变地图方块本身的亮度。

## 3. 创建客舱出生点

每间客舱选一个长方体：

```text
/cruisemurder cabin pos1
/cruisemurder cabin pos2
/cruisemurder cabin create cabin01
```

继续建立 `cabin02` 等客舱。最多 13 名玩家时建议准备 13 间。开局时玩家与客舱会分别打乱，一人分配一间；出生点取选区中心，Y 坐标为选区较低处再往上一格（把客舱地板所在层包含在选区内）。开局前会检查地板、脚下与头顶空间；如果点位被家具堵住、没有可站立地板，或有效客舱数量不足，开局会被拒绝。不同客舱请设置不同的出生位置。

## 4. 目前可用的任务类型

- `SWIM_IN_REGION`：在泳池区域内保持游泳状态达到设定时长。
- `WATCH_IN_REGION`：在电影院区域内朝银幕停留到时间结束。如果设置了 `cinema_screen` 站点，会检测朝向和视线；没有设置时退回区域停留。
- `STAY_IN_REGION`：在甲板、休息室等指定区域停留。
- `EAT_AT_STATION`：在餐厅取餐并吃完，完成餐厅任务。
- `INTERACT_AT_STATION`：从指定控制台开始维修，在附近坚持到计时结束。

每项任务的 `durationSeconds`、`rewardCoins`、`pressureRelief`、`enabled` 和 `region` 均可在 `config/cruisemurder-common.json` 中调整。新版本启动时会把新增配置字段写回该文件；更新前仍建议备份自定义配置。

## 5. 武器与金币

- 杀手可用 `/cruisemurder shop knife` 购买匕首，默认 100 金币。按住右键蓄力，保持约 0.8 秒后松开出手；过早松开不会刺杀。
- 按默认 B 键打开可视化商店（按键可在 Controls 中修改）；也可用 `/cruisemurder shop poison` 购买餐食毒药，默认 30 金币。
- 杀手可在商店购买断电装置，默认 65 金币；默认持续 12 秒，断电装置全局冷却 90 秒。
- 侦探默认有 6 发子弹。每次开枪后默认冷却 30 秒；冷却时间和剩余弹药写在枪械物品上，丢弃或转交都不会清零。
- 射中非杀手会扣除金币并收走手枪；侦探还会失去侦探身份。枪械也可以被其他参与者捡起使用。

## 6. 电影院与遗体联动

对准银幕方块执行 `/cruisemurder station set cinema_screen`。只要设置了这个站点，乘客就必须在 `cinema` 区域里朝银幕看，进度才会增加；未设置时，为兼容旧地图，任务仍只判断区域和时长。`lights_console` 是关灯后的配电箱站点。

如果安装了 Corpse 模组，且 `corpseCompat.keepGameItemsOutOfCorpse` 为 `true`，本模组的匕首、手枪、毒药、断电装置和任务餐食会掉落在遗体旁边，不会进入遗体库存；普通物品仍由 Corpse 管理。

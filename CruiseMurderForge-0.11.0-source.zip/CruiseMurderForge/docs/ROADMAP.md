# Development roadmap

## Implemented in source snapshot 0.11.0

- Round lifecycle: wake countdown, role assignment, timer, coin payouts, win checks, death spectator state, disconnect handling, and original game-mode restoration.
- Configurable player count, timers, economy, task pressure, weapon prices, ammunition, cooldowns, and task definitions. Config is normalized on startup so new fields are written into `config/cruisemurder-common.json`.
- Persistent task regions, interaction stations, and separate randomized cabins; admin commands document how to configure the ship map.
- Personal passenger task assignments with deadlines. Swimming, screen-facing cinema, region stay, dining, and timed engine repair are supported. Missing a deadline adds pressure; completing a task awards coins and reduces pressure.
- Charged right-click knife with server-side role, line-of-sight, range, cooldown, and consumption validation.
- Detective pistol with item-carried ammo and cooldown, server-side raycast, instant elimination, and a penalty for shooting a non-killer. Other players can pick up and use the gun without resetting its per-item state.
- Poison kit for the fixed dining plate; the next meal is poisoned. Poison state clears on round boundaries.
- B-key visual shop. The server validates role, current match state, and coin balance for knife, poison, and blackout device purchases.
- Server-synced HUD with role, coins, round time, pressure, task progress/deadline, detective ammo/cooldown, and blackout state. High pressure adds client-only screen disturbance and fake held items on other players.
- Temporary blackout overlay and an optional `lights_console` repair station. When the optional Corpse mod is present and compatibility is enabled, Cruise Murder equipment drops beside the body rather than going into the corpse inventory.
- Shorter Chinese game notifications and basic item names, models, and tooltips.

## Still required before calling this a complete playable release

- A true texture/skin hallucination renderer; current hallucinations swap other players' held items locally and add screen effects.
- True world/block light manipulation; current blackout uses a dark screen overlay.
- Forge compilation, dedicated-server launch, multiplayer regression testing, GUI/render test, and packaged JAR verification.

This remains an **uncompiled source development build** until the ForgeGradle build succeeds and gameplay has been tested.

# Cruise Murder Forge

A source prototype for a Minecraft 1.20.1 Forge social-deduction minigame set on a cruise ship. Target game size: 2–13 players.

## Current development snapshot (0.11.0)
- Server-side round flow, role assignment, round timer, periodic payouts, win checks, spectator-on-death behavior, and restoration of the player's prior game mode after a round.
- Persistent region, named interaction-station, and cabin configuration; valid, clear, non-duplicated cabin destinations are checked before a round starts, then assigned randomly (one room per player).
- Charged knife: hold right-click, then release to stab; charge time, range, cooldown, cost, and consume-on-kill behavior are configurable.
- Detective pistol: right-click to fire, a per-player cooldown (30 seconds by default), six-round ammo count by default, line-of-sight check, instant player elimination, and a penalty for shooting a non-killer. The gun can be picked up and used by another participant; its remaining ammo travels with the item.
- Killer poison kit: purchase through `/cruisemurder shop poison`, then right-click the configured dining plate to poison the next meal picked up there.
- Personal task assignments with deadlines; overdue tasks add configurable pressure, while completed tasks award coins and reduce pressure. Tasks include swimming, watching a configured cinema screen, deck/lounge time, dining, and a hold-to-repair engine-console station. If a `cinema_screen` station is configured, the cinema task requires the player to face that screen while staying in the cinema region.
- Client HUD synced from the server: role, coins, remaining time, pressure meter, task progress, and the detective gun's remaining ammo/cooldown. High pressure adds screen disturbance and local-only fake hand items on other players.
- A small in-game shop screen opens with **B** by default (the key can be changed in Controls). The server validates purchases and the current coin balance; only the killer can buy the knife, poison kit, or blackout device. The blackout lasts 12 seconds by default and can be ended early at the configured `lights_console` station.
- Shorter Chinese in-game notices and basic item display names/models.

## Build environment
Requires JDK 17 and an internet connection for ForgeGradle and Minecraft dependencies. This source snapshot does not include a Gradle wrapper, and this workspace has no installed Gradle binary. The included GitHub Actions workflow installs Gradle 8.8 and Java 17, builds the mod, then uploads the JAR as a workflow artifact. On GitHub, open **Actions → Build Forge mod → Run workflow** to start it manually, or push to `main`/`master` for an automatic build.

## Important status
This snapshot has **not** been compiled or tested in Minecraft. Treat it as an active development build rather than a ready-to-install mod. The client HUD is an early pass; full skin-texture hallucinations, true world-light changes (the blackout currently darkens each client screen), and end-to-end gameplay testing still remain. When the optional Corpse mod is present and configured, custom minigame gear is dropped beside the body rather than stored inside the corpse inventory. The cabin spawn is one block above the selected room’s lower Y layer, intended to place players above the floor.

## Admin setup
Configure the dining plate, engine console, movie screen, and (optionally) the lights repair panel by looking at the target blocks and running `/cruisemurder station set dining_plate`, `/cruisemurder station set engine_console`, `/cruisemurder station set cinema_screen`, and `/cruisemurder station set lights_console`. The killer can buy equipment from the B-key shop; the configured values are in `config/cruisemurder-common.json`.

In game as an operator, use `/cruisemurder region pos1`, `/cruisemurder region pos2`, and `/cruisemurder region create <id>` to define task regions. Use `/cruisemurder cabin pos1`, `/cruisemurder cabin pos2`, and `/cruisemurder cabin create <id>` to define individual cabin boxes. Run `/cruisemurder region list` and `/cruisemurder cabin list` to review entries. For exact interaction blocks, look at the block and run `/cruisemurder station set dining_plate`, `/cruisemurder station set engine_console`, `/cruisemurder station set cinema_screen`, or `/cruisemurder station set lights_console`; use `/cruisemurder station list` to review them. If `dining_plate` is configured, meals and poison work only at that block. If it is not configured, the dining-region fallback remains active.
